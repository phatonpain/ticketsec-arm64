import React, { useEffect, useMemo, useState } from 'react';
import { ECharts } from './ECharts';
import type { EChartsCoreOption } from '../lib/echarts';
import { useApi, type CategoryStats } from '../hooks/useApi';
import { categoryChartColors, chartColors } from '../lib/chartTokens';

const FALLBACK: CategoryStats[] = [
  { category: 'False Positive', count: 156 },
  { category: 'DDoS', count: 412 },
  { category: 'Data Breach', count: 634 },
  { category: 'Unauthorized Access', count: 982 },
  { category: 'Malware', count: 1245 },
  { category: 'Phishing', count: 1847 },
];

/**
 * Map a category name to a stable --cat-* color.
 * The order matches the categorical palette so chart, table, and donut stay coherent.
 */
function categoryToChartColor(category: string): string {
  const map: Record<string, string> = {
    Phishing: categoryChartColors[0],
    Malware: categoryChartColors[1],
    'Data Breach': categoryChartColors[2],
    'Unauthorized Access': categoryChartColors[3],
    DDoS: categoryChartColors[4],
    'False Positive': categoryChartColors[5],
  };
  return map[category] ?? chartColors.baseline;
}

export const ThreatBarChart: React.FC = () => {
  const { status, getStats, lastSync } = useApi();
  const [data, setData] = useState<CategoryStats[]>(FALLBACK);

  useEffect(() => {
    let mounted = true;
    getStats().then(res => {
      if (!mounted) return;
      if (res && res.length > 0) {
        setData(res);
      }
    });
    return () => { mounted = false; };
  }, [getStats]);

  const sortedData = useMemo(() => {
    return [...data].sort((a, b) => a.count - b.count);
  }, [data]);

  const option: EChartsCoreOption = useMemo(() => {
    const categories = sortedData.map(d => d.category);
    const values = sortedData.map(d => d.count);
    const maxValue = Math.max(...values, 1);

    return {
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        backgroundColor: chartColors.cardBg,
        borderColor: chartColors.baselineFp32,
        borderWidth: 1,
        textStyle: { color: chartColors.textPrimary, fontFamily: 'JetBrains Mono', fontSize: 12 },
        formatter: (params: any) => {
          const p = Array.isArray(params) ? params[0] : params;
          return `${p.name}: ${Number(p.value).toLocaleString('en-US')}`;
        },
      },
      grid: { left: 12, right: 80, top: 12, bottom: 12, containLabel: true },
      xAxis: {
        type: 'value',
        max: maxValue,
        splitLine: {
          show: true,
          lineStyle: { color: 'rgba(255,255,255,0.03)', type: 'solid' },
          interval: maxValue / 4,
        },
        axisLine: { show: false },
        axisTick: { show: false },
        axisLabel: { show: false },
      },
      yAxis: {
        type: 'category',
        data: categories,
        axisLine: { show: false },
        axisTick: { show: false },
        axisLabel: {
          color: chartColors.textMuted,
          fontFamily: 'Inter',
          fontSize: 12,
          margin: 12,
        },
      },
      series: [
        {
          type: 'bar',
          data: values.map((value, i) => ({
            value,
            itemStyle: { color: categoryToChartColor(categories[i]) },
          })),
          barWidth: 18,
          showBackground: true,
          backgroundStyle: { color: 'rgba(255,255,255,0.03)', borderRadius: [0, 4, 4, 0] },
          itemStyle: { borderRadius: [0, 4, 4, 0] },
          label: {
            show: true,
            position: 'right',
            color: chartColors.textPrimary,
            fontFamily: 'JetBrains Mono',
            fontSize: 12,
            formatter: (p: any) => Number(p.value).toLocaleString('en-US'),
          },
          animationDuration: 600,
        },
      ],
    };
  }, [sortedData]);

  const cached = status !== 'live';
  const caption = lastSync && cached
    ? `Snapshot: cached · ${lastSync.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`
    : lastSync
    ? `Last refreshed: ${lastSync.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`
    : 'Snapshot: cached';

  return (
    <div id="threat-chart" className="bg-bg-card border border-border-default rounded-md overflow-hidden hover:border-border-hover transition-colors duration-instant flex flex-col">
      <div className="flex items-center justify-between" style={{ height: 'var(--density-widget-head-h)', padding: '0 20px', boxSizing: 'border-box' }}>
        <div>
          <h2 className="text-[15px] font-semibold text-text-primary tracking-[-0.2px]">Threat Category Distribution</h2>
          <p className="text-xs text-text-muted mt-0.5">Detections by category</p>
        </div>
        {cached && (
          <span className="text-[10px] font-semibold text-accent-amber bg-accent-amber/10 px-2 py-1 rounded">
            CACHED
          </span>
        )}
      </div>
      <div className="px-5 pb-3 flex-1">
        <ECharts option={option} style={{ width: '100%', height: '320px' }} />
      </div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '6px 20px 8px', borderTop: '1px solid var(--border-default)' }}>
        <span style={{ fontSize: 'var(--caption-size)', color: 'var(--caption-color)' }}>{caption}</span>
      </div>
    </div>
  );
};
