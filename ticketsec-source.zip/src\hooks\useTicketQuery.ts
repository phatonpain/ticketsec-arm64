import { useCallback, useSyncExternalStore } from 'react';

interface TicketQueryStore {
  query: string;
  expanded: boolean;
  listeners: Set<() => void>;
}

const store: TicketQueryStore = {
  query: '',
  expanded: false,
  listeners: new Set(),
};

function emit() {
  store.listeners.forEach(listener => listener());
}

function subscribe(listener: () => void) {
  store.listeners.add(listener);
  return () => store.listeners.delete(listener);
}

function getSnapshot(): TicketQueryStore {
  return store;
}

export function setTicketQuery(query: string): void {
  const trimmed = query.trimStart();
  if (trimmed === store.query) return;
  store.query = trimmed;
  emit();
}

export function clearTicketQuery(): void {
  if (store.query === '' && !store.expanded) return;
  store.query = '';
  emit();
}

export function setTicketQueryExpanded(expanded: boolean): void {
  if (expanded === store.expanded) return;
  store.expanded = expanded;
  emit();
}

export function focusTicketQuery(): void {
  store.expanded = true;
  emit();
  window.setTimeout(() => {
    const input = document.getElementById('ticket-query-input');
    if (input) {
      input.focus();
      input.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, 0);
}

export function useTicketQuery() {
  const state = useSyncExternalStore(subscribe, getSnapshot);

  const setQuery = useCallback((value: string) => setTicketQuery(value), []);
  const clear = useCallback(() => clearTicketQuery(), []);
  const setExpanded = useCallback((expanded: boolean) => setTicketQueryExpanded(expanded), []);
  const focus = useCallback(() => focusTicketQuery(), []);

  return {
    query: state.query,
    expanded: state.expanded,
    setQuery,
    clear,
    setExpanded,
    focus,
  };
}
