import React from 'react';

interface ChartSkeletonProps {
  height?: number;
}

export const ChartSkeleton: React.FC<ChartSkeletonProps> = ({ height = 320 }) => (
  <div
    style={{
      width: '100%',
      height,
      background: 'var(--bg-card)',
      borderRadius: 8,
      border: '1px solid var(--border-default)',
      padding: 20,
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      boxSizing: 'border-box',
    }}
    aria-hidden="true"
  >
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div>
        <div
          style={{
            width: 180,
            height: 14,
            background: 'rgba(255,255,255,0.06)',
            borderRadius: 4,
          }}
        />
        <div
          style={{
            width: 120,
            height: 10,
            background: 'rgba(255,255,255,0.04)',
            borderRadius: 4,
            marginTop: 8,
          }}
        />
      </div>
      <div
        style={{
          width: 56,
          height: 18,
          background: 'rgba(255,255,255,0.06)',
          borderRadius: 4,
        }}
      />
    </div>
    <div
      style={{
        flex: 1,
        background: 'rgba(255,255,255,0.03)',
        borderRadius: 6,
      }}
    />
  </div>
);
