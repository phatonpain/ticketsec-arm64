import React, { useMemo } from 'react';
import { ECharts } from './ECharts';
import type { EChartsCoreOption } from '../lib/echarts';
import { chartColors } from '../lib/chartTokens';
import { useApi } from '../hooks/useApi';

// Verifiable sizes only. INT8 artifact size is measured from model/artifact.onnx.
// Memory budget is MemoryMax=700M in ops/ticketsec.service.
const MODEL_INT8_MB = 8.73;
const MEMORY_MAX_MB = 700;
const DATA = [
  { value: MODEL_INT8_MB, name: 'Model (INT8)', color: chartColors.modelInt8 },
  { value: MEMORY_MAX_MB - MODEL_INT8_MB, name: 'Memory headroom', color: chartColors.tokenizerConfig },
];

function calculatePercentages(values: number[]): string[] {
  const total = values.reduce((a, b) => a + b, 0);
  return values.map(v => total > 0 ? `${((v / total) * 100).toFixed(1)}%` : '0.0%');
}

export const ModelHealthDonut: React.FC = () => {
  const { lastSync, status } = useApi();
  const percentages = useMemo(() => calculatePercentages(DATA.map(d => d.value)), []);

  const option: EChartsCoreOption = useMemo(() => ({
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'item',
      backgroundColor: chartColors.cardBg,
      borderColor: chartColors.baselineFp32,
      borderWidth: 1,
      textStyle: { color: chartColors.textPrimary, fontFamily: 'JetBrains Mono', fontSize: 12 },
      formatter: (params: any) => `${params.name}: ${Number(params.value).toFixed(2)}MB`,
    },
    legend: {
      orient: 'vertical',
      right: 10,
      top: 'middle',
      itemWidth: 8,
      itemHeight: 8,
      itemGap: 14,
      icon: 'circle',
      textStyle: {
        color: chartColors.textMuted,
        fontFamily: 'Inter',
        fontSize: 12,
        rich: {
          label: { width: 120, color: chartColors.textMuted, fontSize: 12, fontFamily: 'Inter' },
          value: { width: 56, align: 'right', color: chartColors.textPrimary, fontSize: 12, fontFamily: 'JetBrains Mono' },
          percent: { width: 44, align: 'right', color: chartColors.textMuted, fontSize: 11, fontFamily: 'JetBrains Mono' },
        },
      },
      formatter: (name: string) => {
        const idx = DATA.findIndex(d => d.name === name);
        const item = DATA[idx];
        return `{label|${name}}  {value|${item.value.toFixed(2)}MB}  {percent|${percentages[idx]}}`;
      },
    },
    series: [
      {
        type: 'pie',
        radius: ['42%', '60%'],
        center: ['34%', '50%'],
        avoidLabelOverlap: false,
        label: { show: false },
        emphasis: {
          label: { show: false },
          itemStyle: { shadowBlur: 0 },
        },
        labelLine: { show: false },
        itemStyle: {
          borderRadius: 4,
          borderColor: chartColors.cardBg,
          borderWidth: 2,
        },
        data: DATA.map(item => ({
          value: item.value,
          name: item.name,
          itemStyle: { color: item.color },
        })),
      },
    ],
    graphic: [
      {
        type: 'text',
        left: '25%',
        top: '46%',
        style: {
          text: '8.73MB',
          textAlign: 'center',
          fill: chartColors.textPrimary,
          fontSize: 20,
          fontWeight: 600,
          fontFamily: 'JetBrains Mono',
        },
      },
      {
        type: 'text',
        left: '26%',
        top: '56%',
        style: {
          text: 'Optimized',
          textAlign: 'center',
          fill: chartColors.textMuted,
          fontSize: 11,
          fontFamily: 'Inter',
        },
      },
    ],
  }), [percentages]);

  const cached = status !== 'live';
  const caption = lastSync && cached
    ? `Snapshot: cached · ${lastSync.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`
    : lastSync
    ? `Last refreshed: ${lastSync.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`
    : 'Snapshot: cached';

  return (
    <div id="model-health" className="bg-bg-card border border-border-default rounded-md overflow-hidden hover:border-border-hover transition-colors duration-instant flex flex-col">
      <div className="flex items-center justify-between" style={{ height: 'var(--density-widget-head-h)', padding: '0 20px', boxSizing: 'border-box' }}>
        <div>
          <h2 className="text-[15px] font-semibold text-text-primary tracking-[-0.2px]">Model Footprint</h2>
          <p className="text-xs text-text-muted mt-0.5">INT8 artifact vs t4g.micro memory budget</p>
        </div>
        {cached && (
          <span className="text-[10px] font-semibold text-accent-amber bg-accent-amber/10 px-2 py-1 rounded">
            CACHED
          </span>
        )}
      </div>
      <div className="px-5 pb-3 flex-1">
        <ECharts option={option} style={{ width: '100%', height: '280px' }} />
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 20px 8px', borderTop: '1px solid var(--border-default)' }}>
        <span style={{ fontSize: 'var(--caption-size)', color: 'var(--caption-color)' }}>{caption}</span>
        <span style={{ fontSize: 'var(--caption-size)', color: 'var(--caption-color)' }}>Budget: {MEMORY_MAX_MB}MB</span>
      </div>
    </div>
  );
};
