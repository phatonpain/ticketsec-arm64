import { init, use as registerEchartsModules, type EChartsCoreOption, type EChartsType } from 'echarts/core';
import { BarChart, LineChart, PieChart } from 'echarts/charts';
import {
  TooltipComponent,
  LegendComponent,
  GridComponent,
  GraphicComponent,
  TitleComponent,
} from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';

registerEchartsModules([
  BarChart,
  LineChart,
  PieChart,
  TooltipComponent,
  LegendComponent,
  GridComponent,
  GraphicComponent,
  TitleComponent,
  CanvasRenderer,
]);

export { init };
export type { EChartsCoreOption, EChartsType };
