import React, { Suspense, useEffect, useRef, useState, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { KpiCard } from './components/KpiCard';
import { ChartSkeleton } from './components/ChartSkeleton';
import { SystemMonitor } from './components/SystemMonitor';
import { ClassificationTable } from './components/ClassificationTable';
import { EventLog } from './components/EventLog';
import { LivePrediction } from './components/LivePrediction';
import { HelpModal } from './components/HelpModal';
import { SettingsDrawer } from './components/SettingsDrawer';
import { Zap, Activity, Target, Box } from 'lucide-react';
import { useEventLog } from './hooks/useEventLog';
import { useTickets, loadTicketSnapshot } from './hooks/useTickets';
import { extractLatencySeries, extractThroughputSeries } from './lib/utils';
import { useApi, type PredictionResult, type Classification, type PerformancePoint } from './hooks/useApi';
import evalResults from '../model/eval_results.json';
import { useSettingsDrawer, closeSettingsDrawer } from './hooks/useSettingsDrawer';
import { focusTicketQuery } from './hooks/useTicketQuery';

const ThreatBarChart = React.lazy(() => import('./components/ThreatBarChart').then(m => ({ default: m.ThreatBarChart })));
const PerformanceLineChart = React.lazy(() => import('./components/PerformanceLineChart').then(m => ({ default: m.PerformanceLineChart })));
const ModelHealthDonut = React.lazy(() => import('./components/ModelHealthDonut').then(m => ({ default: m.ModelHealthDonut })));

type EnrichedResult = Omit<PredictionResult, 'processing_time_ms'> & {
  category: string;
  processing_time_ms: string;
};

interface PerClassMetric {
  precision: number;
  recall: number;
  f1: number;
  support: number;
}

interface EvalResults {
  status: 'OK' | 'PENDING' | string;
  overall_accuracy: number | null;
  per_class_metrics: Record<string, PerClassMetric> | null;
}

const typedEvalResults = evalResults as EvalResults;

function macroAverage(metrics: Record<string, PerClassMetric>, key: keyof PerClassMetric): number {
  const values = Object.values(metrics).map(m => m[key]);
  return values.reduce((a, b) => a + b, 0) / values.length;
}

function getAccuracyMetrics(): { value: string; detail: string; pending: boolean } {
  if (typedEvalResults.status !== 'OK' || typedEvalResults.overall_accuracy == null) {
    return { value: '—', detail: 'Awaiting eval — see MODEL_CARD.md', pending: true };
  }
  const accuracy = typedEvalResults.overall_accuracy;
  const perClass = typedEvalResults.per_class_metrics;
  const f1 = perClass ? macroAverage(perClass, 'f1') : null;
  const precision = perClass ? macroAverage(perClass, 'precision') : null;
  const detailParts: string[] = [];
  if (precision != null) detailParts.push(`Precision: ${precision.toFixed(2)}`);
  if (f1 != null) detailParts.push(`F1: ${f1.toFixed(2)}`);
  return {
    value: `${(accuracy * 100).toFixed(0)}%`,
    detail: detailParts.join(' · ') || 'Held-out test accuracy',
    pending: false,
  };
}

function mapClassificationToTicket(c: Classification) {
  return {
    id: c.id,
    subject: c.subject,
    category: c.category,
    confidence: c.confidence,
    status: c.status,
    assignedTo: c.assignedTo,
    createdAt: new Date(c.createdAt),
  };
}

function formatLatency(latency?: number): string {
  if (latency === undefined || latency === null) return '—';
  return latency < 1 ? `${latency.toFixed(2)}ms` : `${latency.toFixed(1)}ms`;
}

function formatThroughput(throughput?: number): string {
  if (throughput === undefined || throughput === null) return '—';
  return throughput.toLocaleString('en-US');
}

function extractLatestKpis(performance: PerformancePoint[]) {
  const latest = performance.length > 0 ? performance[performance.length - 1] : undefined;
  return {
    latency: formatLatency(latest?.latency_ms),
    throughput: formatThroughput(latest?.throughput),
  };
}

function formatDelta(current?: number, previous?: number): string | null {
  if (current === undefined || previous === undefined || previous === 0) return null;
  const delta = current - previous;
  const pct = (delta / previous) * 100;
  const sign = delta >= 0 ? '+' : '';
  return `${sign}${pct.toFixed(1)}%`;
}

function isTypingTarget(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false;
  return target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable;
}

export const App: React.FC = () => {
  const { status, lastSync, getPerformance, getClassifications, checkHealth } = useApi();
  const { addInfo, addError, addWarn } = useEventLog(50);
  const { seed, add } = useTickets();
  const settingsOpen = useSettingsDrawer();

  const [latencyValue, setLatencyValue] = useState<string>('—');
  const [throughputValue, setThroughputValue] = useState<string>('—');
  const [latencyHistory, setLatencyHistory] = useState<number[]>([]);
  const [throughputHistory, setThroughputHistory] = useState<number[]>([]);
  const [latencyDelta, setLatencyDelta] = useState<string | null>(null);
  const [throughputDelta, setThroughputDelta] = useState<string | null>(null);
  const [helpOpen, setHelpOpen] = useState(false);

  const prevStatus = useRef(status);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      const [performance, classifications] = await Promise.all([
        getPerformance(),
        getClassifications(),
      ]);
      if (!mounted) return;

      const hasLivePerformance = performance.length > 0;
      const perfSource = hasLivePerformance ? performance : [];
      const kpis = extractLatestKpis(perfSource);
      const latencySeries = extractLatencySeries(perfSource);
      const throughputSeries = extractThroughputSeries(perfSource);

      setLatencyValue(kpis.latency);
      setThroughputValue(kpis.throughput);
      setLatencyHistory(latencySeries);
      setThroughputHistory(throughputSeries);

      const prevLatency = latencySeries.length > 1 ? latencySeries[latencySeries.length - 2] : undefined;
      const prevThroughput = throughputSeries.length > 1 ? throughputSeries[throughputSeries.length - 2] : undefined;
      const lastLatency = latencySeries[latencySeries.length - 1];
      const lastThroughput = throughputSeries[throughputSeries.length - 1];
      setLatencyDelta(hasLivePerformance ? formatDelta(lastLatency, prevLatency) : null);
      setThroughputDelta(hasLivePerformance ? formatDelta(lastThroughput, prevThroughput) : null);

      if (classifications.length > 0) {
        seed(classifications.map(mapClassificationToTicket));
      } else if (status !== 'live') {
        const loaded = await loadTicketSnapshot();
        if (loaded) {
          addInfo('Cached ticket snapshot loaded');
        }
      }

      if (hasLivePerformance || classifications.length > 0) {
        addInfo('Cached performance and classification data loaded');
      }
    };
    load();
    return () => { mounted = false; };
  }, [getPerformance, getClassifications, seed, addInfo, status]);

  useEffect(() => {
    if (prevStatus.current === status) return;
    if (status === 'live') {
      addInfo('API connection restored');
    } else if (status === 'cached') {
      addWarn('API connection lost — displaying cached data');
    } else if (status === 'offline') {
      addError('API connection lost — no cached data available');
    }
    prevStatus.current = status;
  }, [status, addInfo, addWarn, addError]);

  const handleClassify = useCallback((result: EnrichedResult, text: string) => {
    const ticket = add({
      subject: text,
      category: result.category,
      confidence: result.confidence,
      status: 'Resolved',
      assignedTo: 'Auto',
    });
    addInfo(`Inference OK · ${ticket.id} · ${result.category} · ${result.processing_time_ms}ms`);
  }, [add, addInfo]);

  const handleClassifyError = useCallback((_text: string, errorMessage: string) => {
    addError(`Classification failed · ${errorMessage}`);
  }, [addError]);

  const handleClassifySubmit = useCallback((text: string) => {
    addInfo(`Classification submitted · ${truncateDisplay(text, 40)}`);
  }, [addInfo]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setHelpOpen(false);
        closeSettingsDrawer();
        return;
      }

      if (isTypingTarget(e.target)) return;

      switch (e.key) {
        case '/':
          e.preventDefault();
          focusTicketQuery();
          break;
        case 'r':
        case 'R':
          e.preventDefault();
          void checkHealth();
          addInfo('Manual refresh triggered');
          break;
        case '?':
          e.preventDefault();
          setHelpOpen(true);
          break;
      }
    };
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [checkHealth, addInfo]);

  const cached = status !== 'live';

  return (
    <div style={{ display: 'flex', height: '100vh', background: 'var(--bg-body)', overflow: 'hidden' }}>
      <Sidebar />

      <main style={{ flex: 1, marginLeft: 260, height: '100vh', overflowY: 'auto', display: 'flex', flexDirection: 'column', zIndex: 1 }}>
        <Header />

        {/* Content */}
        <div style={{ flex: 1, padding: '20px 24px', display: 'flex', flexDirection: 'column', gap: 'var(--density-card-gap)' }}>
          {/* Page Title */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <h1 style={{ fontSize: 20, fontWeight: 700, color: 'var(--text-primary)', letterSpacing: '-0.3px', marginBottom: 4 }}>
                Security Operations Center
              </h1>
              <p style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
                Real-time ML ticket classification on AWS Graviton ARM64
              </p>
            </div>
            {lastSync && (
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                Last sync: {lastSync.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </div>
            )}
          </div>

          {/* KPI Row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: 'var(--density-card-gap)' }}>
            <KpiCard
              icon={Zap}
              iconColor="var(--accent-indigo)"
              iconBg="rgba(99,102,241,0.10)"
              label="MODEL LATENCY"
              value={latencyValue}
              detail={cached ? 'Last known latency · cached snapshot' : 'Live metrics endpoint'}
              badge={cached ? { type: 'cached' } : latencyDelta ? { type: 'change', value: latencyDelta, changeType: latencyDelta.startsWith('-') ? 'negative' : 'positive' } : undefined}
              tooltip={{ title: 'Model Latency', note: 'Latency data comes from the live metrics endpoint when available. Sparkline shows the last 24 points.' }}
              sparklineData={latencyHistory}
              sparklineColor="#6366F1"
              muted={cached}
            />
            <KpiCard
              icon={Activity}
              iconColor="var(--accent-cyan)"
              iconBg="rgba(6,182,212,0.10)"
              label="THROUGHPUT"
              value={throughputValue}
              detail={cached ? 'Last known throughput · cached snapshot' : 'Requests / sec'}
              badge={cached ? { type: 'cached' } : throughputDelta ? { type: 'change', value: throughputDelta, changeType: throughputDelta.startsWith('-') ? 'negative' : 'positive' } : undefined}
              tooltip={{ title: 'Throughput', note: 'Throughput data comes from the live metrics endpoint when available. Sparkline shows the last 24 points.' }}
              sparklineData={throughputHistory}
              sparklineColor="#06B6D4"
              muted={cached}
            />
            <KpiCard
              icon={Target}
              iconColor="var(--accent-emerald)"
              iconBg="rgba(16,185,129,0.10)"
              label="MODEL ACCURACY"
              value={(() => {
                const m = getAccuracyMetrics();
                return m.value;
              })()}
              detail={(() => {
                const m = getAccuracyMetrics();
                return m.detail;
              })()}
              badge={(() => {
                const m = getAccuracyMetrics();
                return m.pending ? { type: 'pending' } : { type: 'model-card' };
              })()}
              tooltip={(() => {
                const m = getAccuracyMetrics();
                return m.pending
                  ? { title: 'Model Accuracy', note: 'Awaiting eval — see MODEL_CARD.md' }
                  : { title: 'Model Accuracy', note: 'Held-out test set — see MODEL_CARD.md' };
              })()}
            />
            <KpiCard
              icon={Box}
              iconColor="var(--accent-violet)"
              iconBg="rgba(139,92,246,0.10)"
              label="MODEL FOOTPRINT"
              value="8.73MB"
              detail="ONNX INT8"
              badge={{ type: 'model-card' }}
              tooltip={{ title: 'Model Footprint', note: 'INT8 artifact size — model/artifact.onnx' }}
            />
          </div>

          {/* Charts Row 1 */}
          <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 7fr) minmax(0, 5fr)', gap: 'var(--density-card-gap)' }}>
            <Suspense fallback={<ChartSkeleton height={320} />}>
              <ThreatBarChart />
            </Suspense>
            <div id="model-health">
              <Suspense fallback={<ChartSkeleton height={280} />}>
                <ModelHealthDonut />
              </Suspense>
            </div>
          </div>

          {/* Charts Row 2 */}
          <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 7fr) minmax(0, 5fr)', gap: 'var(--density-card-gap)' }}>
            <Suspense fallback={<ChartSkeleton height={280} />}>
              <PerformanceLineChart />
            </Suspense>
            <SystemMonitor />
          </div>

          {/* Table */}
          <ClassificationTable />

          {/* Bottom Row: Event Log + Live Prediction */}
          <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 7fr) minmax(0, 5fr)', gap: 'var(--density-card-gap)' }}>
            <EventLog />
            <LivePrediction
              onClassify={handleClassify}
              onError={handleClassifyError}
              onSubmit={handleClassifySubmit}
            />
          </div>

          {/* Footer */}
          <footer
            style={{
              borderTop: '1px solid var(--border-default)',
              padding: '16px 0',
              textAlign: 'center',
              fontSize: 12,
              color: 'var(--text-muted)',
            }}
          >
            TicketSec Arm64 Guardian | AWS Graviton Deployment | ONNX Runtime ·{' '}
            <a href="http://3.23.60.61:8000/docs" style={{ color: 'var(--accent-indigo)', textDecoration: 'none' }}>API Docs</a> ·{' '}
            <a href="https://github.com/phatonpain/ticketsec-arm64" style={{ color: 'var(--accent-indigo)', textDecoration: 'none' }}>GitHub</a>
          </footer>
        </div>
      </main>

      <HelpModal open={helpOpen} onClose={() => setHelpOpen(false)} />
      <SettingsDrawer open={settingsOpen} onClose={closeSettingsDrawer} />
    </div>
  );
};

function truncateDisplay(str: string, max: number): string {
  if (str.length <= max) return str;
  return `${str.slice(0, max)}…`;
}
