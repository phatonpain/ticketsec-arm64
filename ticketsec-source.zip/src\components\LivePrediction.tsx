import React, { useState } from 'react';
import { Loader2, Zap, AlertTriangle, RefreshCw } from 'lucide-react';
import { useApi, type PredictionResult } from '../hooks/useApi';
import { CATEGORY_COLORS, CATEGORY_BG } from '../lib/utils';

type EnrichedResult = Omit<PredictionResult, 'processing_time_ms'> & {
  category: string;
  processing_time_ms: string;
};

interface LivePredictionProps {
  onClassify?: (result: EnrichedResult, text: string) => void;
  onError?: (text: string, error: string) => void;
  onSubmit?: (text: string) => void;
}

const EXAMPLES = [
  'suspicious email asking for bank credentials',
  'trojan horse detected in downloaded file',
  'multiple failed login attempts from unknown IP',
];

export const LivePrediction: React.FC<LivePredictionProps> = ({ onClassify, onError, onSubmit }) => {
  const [text, setText] = useState('');
  const [result, setResult] = useState<EnrichedResult | null>(null);
  const [processingTime, setProcessingTime] = useState<string | null>(null);
  const { predict, loading, error } = useApi();

  const handleClassify = async (inputText?: string) => {
    const ticket = inputText ?? text;
    if (!ticket.trim()) return;
    onSubmit?.(ticket);
    setResult(null);
    setProcessingTime(null);
    const start = performance.now();
    const res = await predict(ticket);
    const elapsed = (performance.now() - start).toFixed(2);
    if (res) {
      const enriched = {
        ...res,
        category: res.predicted_category,
        processing_time_ms: elapsed,
      };
      setResult(enriched);
      setProcessingTime(`${elapsed}ms`);
      onClassify?.(enriched, ticket);
    } else {
      onError?.(ticket, error ?? 'API request failed');
    }
  };

  const confidencePercent = result ? result.confidence * 100 : 0;
  const categoryColor = result ? (CATEGORY_COLORS[result.predicted_category] ?? 'var(--text-muted)') : 'var(--text-muted)';

  return (
    <div
      id="live-prediction"
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border-default)',
        borderRadius: 8,
        overflow: 'hidden',
        transition: 'border-color 150ms ease',
        display: 'flex',
        flexDirection: 'column',
        minHeight: 420,
        position: 'relative',
      }}
      onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-hover)'; }}
      onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-default)'; }}
    >
      <div style={{ height: 'var(--density-widget-head-h)', padding: '0 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', boxSizing: 'border-box' }}>
        <div>
          <h2 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-primary)', letterSpacing: '-0.2px' }}>Live Classification</h2>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 1 }}>Submit a ticket for real-time prediction</p>
        </div>
      </div>
      <div style={{ padding: '0 20px 16px', flex: 1, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <textarea
          value={text}
          onChange={e => setText(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); handleClassify(); } }}
          placeholder="Paste ticket subject or body here…"
          rows={4}
          aria-label="Ticket text"
          style={{
            width: '100%',
            background: 'var(--bg-input)',
            border: '1px solid var(--border-default)',
            borderRadius: 8,
            padding: 12,
            fontSize: 13,
            color: 'var(--text-primary)',
            fontFamily: 'Inter, sans-serif',
            resize: 'none',
            outline: 'none',
            boxSizing: 'border-box',
          }}
        />
        <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: -4 }}>Ctrl+Enter to submit</div>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {EXAMPLES.map(ex => (
            <button
              key={ex}
              onClick={() => { setText(ex); handleClassify(ex); }}
              style={{
                fontSize: 11,
                color: 'var(--text-secondary)',
                background: 'var(--bg-body)',
                border: '1px solid var(--border-default)',
                borderRadius: 4,
                padding: '4px 8px',
                cursor: 'pointer',
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-hover)'; (e.currentTarget as HTMLElement).style.color = 'var(--text-primary)'; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-default)'; (e.currentTarget as HTMLElement).style.color = 'var(--text-secondary)'; }}
            >
              {ex}
            </button>
          ))}
        </div>

        <button
          onClick={() => handleClassify()}
          disabled={loading || !text.trim()}
          style={{
            width: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 8,
            background: 'var(--accent-indigo)',
            color: '#fff',
            border: 'none',
            borderRadius: 6,
            padding: '8px 16px',
            fontSize: 13,
            fontWeight: 600,
            cursor: loading || !text.trim() ? 'not-allowed' : 'pointer',
            opacity: loading || !text.trim() ? 0.6 : 1,
          }}
        >
          {loading && <Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} />}
          {loading ? 'Classifying…' : <><Zap size={16} /> Classify Ticket</>}
        </button>

        {!result && !loading && !error && (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, padding: '24px 0', color: 'var(--text-muted)', textAlign: 'center' }}>
            <Zap size={24} style={{ opacity: 0.3 }} />
            <span style={{ fontSize: 12 }}>Submit a ticket to see the real-time prediction result.</span>
          </div>
        )}

        {error && !result && (
          <div style={{ background: 'rgba(244, 63, 94, 0.08)', border: '1px solid rgba(244, 63, 94, 0.30)', borderRadius: 8, padding: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--accent-rose)', fontWeight: 600 }}>
              <AlertTriangle size={14} />
              Classification failed
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{error}</div>
            <button
              onClick={() => handleClassify()}
              disabled={loading}
              style={{
                alignSelf: 'flex-start',
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                padding: '5px 10px',
                borderRadius: 6,
                border: '1px solid var(--border-default)',
                background: 'var(--bg-body)',
                color: 'var(--text-primary)',
                fontSize: 12,
                cursor: 'pointer',
              }}
            >
              <RefreshCw size={12} /> Retry
            </button>
          </div>
        )}

        {result && (
          <div style={{ background: 'var(--bg-body)', border: '1px solid var(--border-default)', borderRadius: 8, padding: 14, display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', fontWeight: 600 }}>Category</span>
              <span
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 6,
                  padding: '2px 8px',
                  borderRadius: 4,
                  fontSize: 12,
                  fontWeight: 600,
                  background: CATEGORY_BG[result.predicted_category] || 'rgba(100,116,139,0.12)',
                  color: categoryColor,
                }}
              >
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: categoryColor }} />
                {result.predicted_category.replace(/_/g, ' ')}
              </span>
            </div>

            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', fontWeight: 600 }}>Confidence</span>
                <span style={{ fontSize: 18, fontFamily: 'var(--font-numeric)', fontVariantNumeric: 'tabular-nums', fontWeight: 600, color: 'var(--text-primary)' }}>
                  {confidencePercent.toFixed(1)}%
                </span>
              </div>
              <div style={{ position: 'relative', height: 6, background: 'rgba(255,255,255,0.06)', borderRadius: 3 }}>
                <div
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    height: '100%',
                    width: `${confidencePercent}%`,
                    background: categoryColor,
                    borderRadius: 3,
                    transition: 'width 300ms ease',
                  }}
                />
                <div
                  style={{
                    position: 'absolute',
                    top: -3,
                    left: '70%',
                    width: 2,
                    height: 12,
                    background: 'var(--text-muted)',
                    borderRadius: 1,
                  }}
                  title="Decision threshold (70%)"
                />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: 'var(--text-muted)', marginTop: 4 }}>
                <span>0%</span>
                <span>Threshold 70%</span>
                <span>100%</span>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', fontWeight: 600 }}>Latency</span>
              <span style={{ fontFamily: 'var(--font-numeric)', fontVariantNumeric: 'tabular-nums', fontSize: 13, color: 'var(--accent-cyan)' }}>{processingTime}</span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', fontWeight: 600 }}>Model</span>
              <span style={{ fontSize: 12, color: 'var(--text-secondary)', fontFamily: 'var(--font-numeric)' }}>onnx-int8 · arm64</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
