import React from 'react';
import { LayoutDashboard, FolderOpen, ShieldAlert, BarChart3, Search, Zap, Box, HeartPulse, Activity, Settings, X } from 'lucide-react';
import { useTicketQuery, focusTicketQuery } from '../hooks/useTicketQuery';
import { openSettingsDrawer } from '../hooks/useSettingsDrawer';

interface NavItem {
  icon: React.ComponentType<{ size?: number; color?: string; 'aria-hidden'?: boolean }>;
  label: string;
  active?: boolean;
  action: () => void;
}

interface NavSection {
  label: string;
  items: NavItem[];
}

export const Sidebar: React.FC = () => {
  const { query, setQuery, clear } = useTicketQuery();

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    el?.scrollIntoView({ behavior: 'smooth' });
  };



  const sections: NavSection[] = [
    {
      label: 'OVERVIEW',
      items: [
        { icon: LayoutDashboard, label: 'Dashboard', active: true, action: scrollToTop },
        { icon: FolderOpen, label: 'Cases', action: () => scrollTo('classifications-table') },
        { icon: ShieldAlert, label: 'Detections', action: () => scrollTo('threat-chart') },
        { icon: BarChart3, label: 'Threat Analytics', action: () => scrollTo('performance-chart') },
      ],
    },
    {
      label: 'OPERATIONS',
      items: [
        {
          icon: Search,
          label: 'Ticket Query',
          action: focusTicketQuery,
        },
        { icon: Zap, label: 'Live Predictions', action: () => scrollTo('live-prediction') },
        { icon: Box, label: 'Model Registry', action: () => scrollTo('model-health') },
      ],
    },
    {
      label: 'SYSTEM',
      items: [
        { icon: HeartPulse, label: 'System Health', action: () => scrollTo('system-monitor') },
        { icon: Activity, label: 'API Metrics', action: () => scrollTo('performance-chart') },
        { icon: Settings, label: 'Settings', action: openSettingsDrawer },
      ],
    },
  ];

  return (
    <>
      <aside
        style={{
          width: 260,
          background: 'var(--bg-sidebar)',
          borderRight: '1px solid var(--border-default)',
          display: 'flex',
          flexDirection: 'column',
          position: 'fixed',
          top: 0,
          bottom: 0,
          left: 0,
          zIndex: 100,
        }}
      >
        {/* Brand */}
        <div
          style={{
            padding: '20px 24px 16px 20px',
            borderBottom: '1px solid var(--border-default)',
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            flexShrink: 0,
          }}
        >
          <div
            style={{
              width: 32,
              height: 32,
              borderRadius: 8,
              background: 'var(--bg-input)',
              border: '1px solid var(--border-default)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 13,
              fontWeight: 700,
              color: 'var(--text-primary)',
              flexShrink: 0,
            }}
          >
            T
          </div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-primary)' }}>TicketSec</div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>Arm64 Guardian</div>
          </div>
        </div>

        {/* Navigation — scrollable */}
        <nav
          style={{
            flex: 1,
            minHeight: 0,
            overflowY: 'auto',
            padding: '12px 12px 0',
          }}
        >
          {sections.map(section => (
            <div key={section.label} style={{ marginBottom: 16 }}>
              <div
                style={{
                  fontSize: 10,
                  fontWeight: 700,
                  color: 'var(--text-muted)',
                  textTransform: 'uppercase',
                  letterSpacing: '1px',
                  padding: '12px 12px 8px',
                }}
              >
                {section.label}
              </div>
              {section.items.map(item => {
                const Icon = item.icon;
                return (
                  <React.Fragment key={item.label}>
                    <button
                      type="button"
                      onClick={item.action}
                      aria-current={item.active ? 'page' : undefined}
                      style={{
                        width: '100%',
                        display: 'flex',
                        alignItems: 'center',
                        gap: 12,
                        padding: '9px 14px',
                        borderRadius: 8,
                        fontSize: 13,
                        fontWeight: item.active ? 600 : 500,
                        color: item.active ? 'var(--text-primary)' : 'var(--text-secondary)',
                        background: item.active ? 'rgba(99,102,241,0.10)' : 'transparent',
                        borderLeft: item.active ? '3px solid var(--accent-indigo)' : '3px solid transparent',
                        borderTop: 'none',
                        borderRight: 'none',
                        borderBottom: 'none',
                        cursor: 'pointer',
                        transition: 'all 150ms ease',
                        marginBottom: 2,
                        textAlign: 'left',
                        fontFamily: 'inherit',
                      }}
                      onMouseEnter={(e) => {
                        if (!item.active) (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)';
                      }}
                      onMouseLeave={(e) => {
                        if (!item.active) (e.currentTarget as HTMLElement).style.background = 'transparent';
                      }}
                    >
                      <span style={{ display: 'flex', alignItems: 'center' }}>
                        <Icon size={18} color={item.active ? 'var(--accent-indigo)' : 'var(--text-muted)'} aria-hidden />
                      </span>
                      {item.label}
                    </button>
                    {item.label === 'Ticket Query' && (
                      <div style={{ padding: '0 14px 8px 44px' }}>
                        <input
                          id="ticket-query-input"
                          value={query}
                          onChange={e => setQuery(e.target.value)}
                          onKeyDown={e => { if (e.key === 'Enter') { /* query applies live */ } }}
                          placeholder="Search tickets..."
                          aria-label="Search tickets"
                          style={{
                            width: '100%',
                            padding: '6px 10px',
                            borderRadius: 6,
                            border: '1px solid var(--border-default)',
                            background: 'var(--bg-input)',
                            color: 'var(--text-primary)',
                            fontSize: 12,
                            outline: 'none',
                          }}
                        />
                        {query && (
                          <button
                            type="button"
                            onClick={clear}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: 4,
                              marginTop: 6,
                              padding: 0,
                              background: 'transparent',
                              border: 'none',
                              color: 'var(--text-muted)',
                              fontSize: 11,
                              cursor: 'pointer',
                            }}
                          >
                            <X size={12} />
                            Clear filter
                          </button>
                        )}
                      </div>
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          ))}
        </nav>

        {/* User Card — pinned at bottom */}
        <div style={{ padding: 12, flexShrink: 0, borderTop: '1px solid var(--border-default)' }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              padding: 12,
              background: 'var(--bg-card)',
              border: '1px solid var(--border-default)',
              borderRadius: 10,
            }}
          >
            <div
              style={{
                width: 32,
                height: 32,
                borderRadius: '50%',
                background: 'var(--bg-input)',
                border: '1px solid var(--border-default)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 12,
                fontWeight: 600,
                color: 'var(--text-primary)',
              }}
            >
              FI
            </div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)' }}>Felipe Inacio</div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Security Analyst</div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
