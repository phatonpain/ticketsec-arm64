import { useEffect, useSyncExternalStore } from 'react';
import { getApiBase } from './useSettings';

export type ApiStatus = 'live' | 'cached' | 'offline';

export interface PredictionResult {
  predicted_category: string;
  confidence: number;
  processing_time_ms?: number;
  probabilities?: Record<string, number>;
}

export interface CategoryStats {
  category: string;
  count: number;
}

export interface PerformancePoint {
  time: string;
  baseline: number;
  onnx: number;
  int8: number;
  latency_ms?: number;
  throughput?: number;
}

export interface Classification {
  id: string;
  subject: string;
  category: string;
  confidence: number;
  status: 'Resolved' | 'Escalated' | 'Pending';
  assignedTo: string;
  createdAt: string;
}

interface Cache {
  categories: CategoryStats[];
  performance: PerformancePoint[];
  classifications: Classification[];
}

export interface ProbeEndpoint {
  url: string;
  ok: boolean;
  latencyMs: number;
  error?: string;
}

export interface Diagnostics {
  lastProbe: Date | null;
  lastError: string | null;
  endpoints: ProbeEndpoint[];
}

interface ApiStoreState {
  status: ApiStatus;
  checking: boolean;
  loading: boolean;
  error: string | null;
  lastSync: Date | null;
  diagnostics: Diagnostics;
}

interface ApiStore extends ApiStoreState {
  listeners: Set<() => void>;
}

const HEALTH_TIMEOUT_MS = 10_000;
const PREDICT_TIMEOUT_MS = 15_000;
const BASE_RECOVERY_INTERVAL_MS = 30_000;
const MAX_RECOVERY_INTERVAL_MS = 300_000;

const cache: Cache = {
  categories: [],
  performance: [],
  classifications: [],
};

const store: ApiStore = {
  status: 'offline',
  checking: true,
  loading: false,
  error: null,
  lastSync: null,
  diagnostics: { lastProbe: null, lastError: null, endpoints: [] },
  listeners: new Set(),
};

let isProbing = false;
let consecutiveFailures = 0;
let recoveryTimer: number | null = null;
let recoveryStarted = false;

function emit() {
  store.listeners.forEach(listener => listener());
}

function subscribe(listener: () => void) {
  store.listeners.add(listener);
  return () => store.listeners.delete(listener);
}

function getSnapshot(): ApiStore {
  return store;
}

function hasAnyCache(): boolean {
  return cache.categories.length > 0 || cache.performance.length > 0 || cache.classifications.length > 0;
}

function updateStatus(online: boolean): void {
  if (online) {
    store.status = 'live';
    store.lastSync = new Date();
    store.diagnostics = { ...store.diagnostics, lastError: null };
  } else {
    store.status = hasAnyCache() ? 'cached' : 'offline';
  }
  emit();
}

async function fetchWithTimeout(url: string, options: RequestInit = {}, timeoutMs: number): Promise<Response> {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...options, signal: controller.signal });
    return res;
  } finally {
    window.clearTimeout(timeout);
  }
}

async function probeSingleEndpoint(url: string): Promise<ProbeEndpoint> {
  const start = performance.now();
  try {
    const res = await fetchWithTimeout(url, { method: 'GET' }, HEALTH_TIMEOUT_MS);
    const latencyMs = Math.round(performance.now() - start);
    if (res.ok) {
      return { url, ok: true, latencyMs };
    }
    return { url, ok: false, latencyMs, error: `HTTP ${res.status}` };
  } catch (err) {
    const latencyMs = Math.round(performance.now() - start);
    return { url, ok: false, latencyMs, error: err instanceof Error ? err.name : 'Network error' };
  }
}

async function runHealthProbe(baseUrl: string): Promise<{ online: boolean; endpoints: ProbeEndpoint[]; error: string | null }> {
  const candidates = [`${baseUrl}/health`, `${baseUrl}/`, `${baseUrl}/docs`];
  const endpoints = await Promise.all(candidates.map(probeSingleEndpoint));
  const online = endpoints.some(e => e.ok);
  const firstFailure = endpoints.find(e => !e.ok);
  return {
    online,
    endpoints,
    error: online ? null : (firstFailure?.error ?? 'All endpoints unreachable'),
  };
}

export async function probeApiBase(url: string): Promise<{ ok: boolean; endpoints: ProbeEndpoint[]; error: string | null }> {
  const result = await runHealthProbe(url);
  return { ok: result.online, endpoints: result.endpoints, error: result.error };
}

export async function checkHealth(): Promise<void> {
  if (isProbing) return;
  isProbing = true;
  store.checking = true;
  emit();

  try {
    const result = await runHealthProbe(getApiBase());
    if (result.online) {
      consecutiveFailures = 0;
    } else {
      consecutiveFailures = Math.min(consecutiveFailures + 1, 6);
    }
    store.diagnostics = {
      lastProbe: new Date(),
      lastError: result.error,
      endpoints: result.endpoints,
    };
    updateStatus(result.online);
  } catch {
    consecutiveFailures = Math.min(consecutiveFailures + 1, 6);
    store.diagnostics = {
      ...store.diagnostics,
      lastProbe: new Date(),
      lastError: 'Unexpected probe failure',
    };
    updateStatus(false);
  } finally {
    store.checking = false;
    isProbing = false;
    emit();
  }
}

function scheduleNextProbe(): void {
  if (recoveryTimer) window.clearTimeout(recoveryTimer);
  const backoffMultiplier = Math.min(2 ** consecutiveFailures, MAX_RECOVERY_INTERVAL_MS / BASE_RECOVERY_INTERVAL_MS);
  const delay = Math.round(BASE_RECOVERY_INTERVAL_MS * backoffMultiplier);
  recoveryTimer = window.setTimeout(() => {
    void checkHealth().then(scheduleNextProbe);
  }, delay);
}

function startAutoRecovery(): void {
  if (recoveryStarted) return;
  recoveryStarted = true;
  scheduleNextProbe();
}

export async function predict(text: string): Promise<PredictionResult | null> {
  store.loading = true;
  store.error = null;
  emit();
  try {
    const res = await fetchWithTimeout(
      `${getApiBase()}/predict`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      },
      PREDICT_TIMEOUT_MS,
    );
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data: PredictionResult = await res.json();
    updateStatus(true);
    return data;
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    store.error = message;
    return null;
  } finally {
    store.loading = false;
    emit();
  }
}

export async function getStats(): Promise<CategoryStats[]> {
  try {
    const res = await fetchWithTimeout(`${getApiBase()}/api/v1/stats/categories`, { method: 'GET' }, HEALTH_TIMEOUT_MS);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data: CategoryStats[] = await res.json();
    cache.categories = data;
    return data;
  } catch {
    return cache.categories.length > 0 ? cache.categories : [];
  }
}

export async function getPerformance(): Promise<PerformancePoint[]> {
  try {
    const res = await fetchWithTimeout(`${getApiBase()}/api/v1/performance/history`, { method: 'GET' }, HEALTH_TIMEOUT_MS);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data: PerformancePoint[] = await res.json();
    cache.performance = data;
    return data;
  } catch {
    return cache.performance.length > 0 ? cache.performance : [];
  }
}

export async function getClassifications(): Promise<Classification[]> {
  try {
    const res = await fetchWithTimeout(`${getApiBase()}/api/v1/classifications`, { method: 'GET' }, HEALTH_TIMEOUT_MS);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data: Classification[] = await res.json();
    cache.classifications = data;
    return data;
  } catch {
    return cache.classifications.length > 0 ? cache.classifications : [];
  }
}

export function useApi() {
  const state = useSyncExternalStore(subscribe, getSnapshot);

  useEffect(() => {
    void checkHealth();
    startAutoRecovery();

    const onVisible = () => {
      if (!document.hidden) {
        void checkHealth();
      }
    };
    const onFocus = () => {
      void checkHealth();
    };

    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onFocus);

    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', onFocus);
    };
  }, []);

  return {
    status: state.status,
    checking: state.checking,
    loading: state.loading,
    error: state.error,
    lastSync: state.lastSync,
    diagnostics: state.diagnostics,
    checkHealth,
    predict,
    getStats,
    getPerformance,
    getClassifications,
  };
}
