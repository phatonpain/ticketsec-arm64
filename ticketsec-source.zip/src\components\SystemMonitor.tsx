import React from 'react';
import { useApi } from '../hooks/useApi';

interface MetricTileProps {
  label: string;
  value: string;
  sub: string;
  percent?: number;
  fill?: string;
  muted?: boolean;
}

const MetricTile: React.FC<MetricTileProps> = ({ label, value, sub, percent, fill, muted }) => (
  <div>
    <div style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 500, marginBottom: 6 }}>{label}</div>
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 6 }}>
      <span
        style={{
          fontSize: 18,
          fontFamily: 'var(--font-numeric)',
          fontVariantNumeric: 'tabular-nums',
          fontWeight: 600,
          color: muted ? 'var(--text-muted)' : 'var(--text-primary)',
          letterSpacing: '-0.3px',
        }}
      >
        {value}
      </span>
      <span
        style={{
          fontSize: 10,
          color: 'var(--text-muted)',
          whiteSpace: 'nowrap',
          marginLeft: 'auto',
          textAlign: 'right',
        }}
      >
        {sub}
      </span>
    </div>
    <div style={{ height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden' }}>
      <div
        style={{
          height: '100%',
          borderRadius: 2,
          background: fill ?? 'var(--text-muted)',
          width: `${percent ?? 0}%`,
          transition: 'width 200ms ease',
        }}
      />
    </div>
  </div>
);

export const SystemMonitor: React.FC = () => {
  const { status, lastSync } = useApi();
  const offline = status !== 'live';
  const offlineSub = 'Unavailable — API offline';

  const caption = lastSync && offline
    ? `Snapshot: cached · ${lastSync.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`
    : lastSync
    ? `Last refreshed: ${lastSync.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`
    : 'Snapshot: cached';

  return (
    <div
      id="system-monitor"
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border-default)',
        borderRadius: 8,
        overflow: 'hidden',
        transition: 'border-color 150ms ease',
        display: 'flex',
        flexDirection: 'column',
      }}
      onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-hover)'; }}
      onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-default)'; }}
    >
      <div style={{ height: 'var(--density-widget-head-h)', padding: '0 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', boxSizing: 'border-box' }}>
        <div>
          <h2 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-primary)', letterSpacing: '-0.2px' }}>System Monitor</h2>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 1 }}>ARM64 infrastructure resources</p>
        </div>
        <span
          style={{
            fontSize: 10,
            fontWeight: 600,
            color: offline ? 'var(--accent-amber)' : 'var(--accent-emerald)',
            background: offline ? 'rgba(245, 158, 11, 0.10)' : 'rgba(16, 185, 129, 0.10)',
            border: `1px solid ${offline ? 'rgba(245, 158, 11, 0.30)' : 'rgba(16, 185, 129, 0.30)'}`,
            borderRadius: 4,
            padding: '3px 8px',
          }}
        >
          {offline ? 'CACHED' : 'LIVE'}
        </span>
      </div>
      <div style={{ padding: '0 20px 16px', flex: 1 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px 28px' }}>
          <MetricTile
            label="CPU (Neoverse N1)"
            value={offline ? '—' : '2 vCPUs'}
            sub={offline ? offlineSub : 't4g.micro'}
            percent={offline ? 0 : 100}
            fill="var(--accent-indigo)"
            muted={offline}
          />
          <MetricTile
            label="Memory (RAM)"
            value={offline ? '—' : '1GB'}
            sub={offline ? offlineSub : 't4g.micro'}
            percent={offline ? 0 : 100}
            fill="var(--accent-emerald)"
            muted={offline}
          />
          <MetricTile
            label="API Latency"
            value="—"
            sub={offlineSub}
            percent={0}
            fill="var(--text-muted)"
            muted
          />
          <MetricTile
            label="Requests / Min"
            value="—"
            sub={offlineSub}
            percent={0}
            fill="var(--text-muted)"
            muted
          />
        </div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '6px 20px 8px', borderTop: '1px solid var(--border-default)' }}>
        <span style={{ fontSize: 'var(--caption-size)', color: 'var(--caption-color)' }}>{caption}</span>
      </div>
    </div>
  );
};
