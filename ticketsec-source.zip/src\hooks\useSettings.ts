import { useCallback, useEffect, useSyncExternalStore } from 'react';

const STORAGE_KEY = 'ticketsec-settings-v1';
const DEFAULT_API_BASE = import.meta.env.VITE_API_BASE_URL ?? 'http://3.23.60.61:8000';

export interface Settings {
  apiBase: string;
  reducedMotion: boolean;
}

interface SettingsStore {
  settings: Settings;
  listeners: Set<() => void>;
}

const store: SettingsStore = {
  settings: loadSettings(),
  listeners: new Set(),
};

function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<Settings>;
      return {
        apiBase: normalizeApiBase(parsed.apiBase) ?? DEFAULT_API_BASE,
        reducedMotion: Boolean(parsed.reducedMotion),
      };
    }
  } catch {
    // Ignore corrupted storage and fall back to defaults.
  }
  return {
    apiBase: DEFAULT_API_BASE,
    reducedMotion: false,
  };
}

function saveSettings(settings: Settings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // Storage may be unavailable in private mode or restricted contexts.
  }
}

function normalizeApiBase(url: string | undefined): string | undefined {
  if (!url) return undefined;
  const trimmed = url.trim();
  if (!trimmed) return undefined;
  // Allow users to type host:port; default to http:// for convenience.
  if (/^\d+\.\d+\.\d+\.\d+(:\d+)?$/.test(trimmed) || /^[\w.-]+(:\d+)?$/.test(trimmed)) {
    return `http://${trimmed}`;
  }
  return trimmed;
}

function emit() {
  store.listeners.forEach(listener => listener());
}

function subscribe(listener: () => void) {
  store.listeners.add(listener);
  return () => store.listeners.delete(listener);
}

function getSnapshot(): Settings {
  return store.settings;
}

function applyReducedMotion(reduced: boolean): void {
  if (reduced) {
    document.documentElement.setAttribute('data-reduced-motion', 'true');
  } else {
    document.documentElement.removeAttribute('data-reduced-motion');
  }
}

export function getApiBase(): string {
  return store.settings.apiBase;
}

export function setApiBase(url: string): void {
  const normalized = normalizeApiBase(url) ?? DEFAULT_API_BASE;
  if (normalized === store.settings.apiBase) return;
  store.settings = { ...store.settings, apiBase: normalized };
  saveSettings(store.settings);
  emit();
}

export function setReducedMotion(reduced: boolean): void {
  if (reduced === store.settings.reducedMotion) return;
  store.settings = { ...store.settings, reducedMotion: reduced };
  saveSettings(store.settings);
  applyReducedMotion(reduced);
  emit();
}

export function resetSettings(): void {
  store.settings = { apiBase: DEFAULT_API_BASE, reducedMotion: false };
  saveSettings(store.settings);
  applyReducedMotion(false);
  emit();
}

export function useSettings() {
  const settings = useSyncExternalStore(subscribe, getSnapshot);

  useEffect(() => {
    applyReducedMotion(settings.reducedMotion);
  }, [settings.reducedMotion]);

  const updateApiBase = useCallback((url: string) => setApiBase(url), []);
  const updateReducedMotion = useCallback((reduced: boolean) => setReducedMotion(reduced), []);
  const restoreDefaults = useCallback(() => resetSettings(), []);

  return {
    settings,
    updateApiBase,
    updateReducedMotion,
    restoreDefaults,
  };
}

// Apply persisted preference as early as possible to avoid a flash of motion.
applyReducedMotion(store.settings.reducedMotion);
