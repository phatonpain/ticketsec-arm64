import React, { useState, useMemo, useEffect } from 'react';
import { Download } from 'lucide-react';
import { useTickets, type Ticket } from '../hooks/useTickets';
import { useTicketQuery } from '../hooks/useTicketQuery';
import { useApi } from '../hooks/useApi';
import {
  CATEGORY_COLORS,
  CATEGORY_BG,
  CATEGORY_SEVERITY,
  SEVERITY_COLORS,
  SEVERITY_LABEL,
  STATUS_COLORS,
  truncate,
} from '../lib/utils';
import { formatRelativeTime } from '../lib/formatRelativeTime';
import { exportTicketsToCsv } from '../lib/exportCsv';

type SortKey = 'id' | 'category' | 'severity' | 'confidence' | 'status' | 'time';
type SortDir = 'asc' | 'desc';

function sortTickets(tickets: Ticket[], key: SortKey, dir: SortDir): Ticket[] {
  const sorted = [...tickets];
  sorted.sort((a, b) => {
    let comparison = 0;
    if (key === 'confidence') {
      comparison = a.confidence - b.confidence;
    } else if (key === 'id') {
      comparison = a.id.localeCompare(b.id);
    } else if (key === 'category') {
      comparison = a.category.localeCompare(b.category);
    } else if (key === 'severity') {
      const sevA = CATEGORY_SEVERITY[a.category] ?? 'info';
      const sevB = CATEGORY_SEVERITY[b.category] ?? 'info';
      const rank: Record<string, number> = { critical: 4, high: 3, medium: 2, info: 1 };
      comparison = rank[sevA] - rank[sevB];
    } else if (key === 'status') {
      comparison = a.status.localeCompare(b.status);
    } else if (key === 'time') {
      comparison = a.createdAt.getTime() - b.createdAt.getTime();
    }
    return dir === 'asc' ? comparison : -comparison;
  });
  return sorted;
}

function matchesQuery(ticket: Ticket, query: string): boolean {
  if (!query) return true;
  const q = query.toLowerCase();
  return (
    ticket.id.toLowerCase().includes(q) ||
    ticket.subject.toLowerCase().includes(q) ||
    ticket.category.toLowerCase().includes(q) ||
    ticket.status.toLowerCase().includes(q) ||
    ticket.assignedTo.toLowerCase().includes(q)
  );
}

function formatLastRefreshed(lastSync: Date | null, status: string): string {
  if (!lastSync) return status === 'live' ? 'Live' : 'Snapshot: cached';
  const time = lastSync.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  return status === 'live' ? `Last refreshed: ${time}` : `Snapshot: cached · ${time}`;
}

export const ClassificationTable: React.FC = () => {
  const { status, lastSync } = useApi();
  const { tickets } = useTickets();
  const { query, clear } = useTicketQuery();
  const [page, setPage] = useState(1);
  const [sortKey, setSortKey] = useState<SortKey>('time');
  const [sortDir, setSortDir] = useState<SortDir>('desc');

  const pageSize = 5;

  useEffect(() => {
    setPage(1);
  }, [tickets.length, query]);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('desc');
    }
    setPage(1);
  };

  const filteredRows = useMemo(() => {
    return tickets.filter(t => matchesQuery(t, query));
  }, [tickets, query]);

  const sortedRows = useMemo(() => sortTickets(filteredRows, sortKey, sortDir), [filteredRows, sortKey, sortDir]);

  const totalCount = sortedRows.length;
  const pageCount = Math.max(1, Math.ceil(totalCount / pageSize));
  const currentPage = Math.min(page, pageCount);
  const paginatedRows = sortedRows.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const thBaseStyle: React.CSSProperties = {
    padding: '6px 12px',
    fontSize: 11,
    fontWeight: 600,
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
    color: 'var(--text-muted)',
    textAlign: 'left',
    whiteSpace: 'nowrap',
    height: 'var(--density-widget-head-h)',
    boxSizing: 'border-box',
  };

  const tdStyle: React.CSSProperties = {
    padding: '0 12px',
    fontSize: 12,
    color: 'var(--text-primary)',
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    maxWidth: 0,
    height: 'var(--density-row-h)',
    boxSizing: 'border-box',
  };

  const SortableHeader: React.FC<{ label: string; colKey: SortKey; width: number | string }> = ({ label, colKey, width }) => {
    const active = sortKey === colKey;
    const ariaSort = active ? (sortDir === 'asc' ? 'ascending' : 'descending') : 'none';
    return (
      <th scope="col" aria-sort={ariaSort} style={{ ...thBaseStyle, width }}>
        <button
          onClick={() => handleSort(colKey)}
          style={{
            ...thBaseStyle,
            background: 'transparent',
            border: 'none',
            cursor: 'pointer',
            display: 'inline-flex',
            alignItems: 'center',
            gap: 4,
            fontFamily: 'inherit',
            padding: 0,
            height: 'auto',
          }}
        >
          {label}
          <span style={{ fontSize: 10, color: active ? 'var(--text-primary)' : 'var(--text-muted)' }}>
            {active ? (sortDir === 'asc' ? '▲' : '▼') : '⇅'}
          </span>
        </button>
      </th>
    );
  };

  const subtitle = status === 'live' ? 'Live API predictions' : 'Cached predictions — API offline';
  const offline = status !== 'live';
  const hasRows = totalCount > 0;
  const offlineBadgeText = hasRows ? 'API Offline — Displaying cached data' : 'API Offline — no cached data available';

  const handleExport = () => {
    const timestamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    exportTicketsToCsv(sortedRows, `ticketsec-classifications-${timestamp}.csv`);
  };

  return (
    <div id="classifications-table" className="bg-bg-card border border-border-default rounded-md overflow-hidden hover:border-border-hover transition-colors duration-instant">
      <div className="px-5 pt-4 pb-3 flex items-center justify-between" style={{ height: 'var(--density-widget-head-h)', padding: '0 20px', boxSizing: 'border-box' }}>
        <div>
          <h2 className="text-sm font-semibold text-text-primary tracking-[-0.2px]">Recent Classifications</h2>
          <p className="text-xs text-text-muted mt-0.5">
            {subtitle}
            {query && ` · filtered by “${query}”`}
          </p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {query && (
            <button
              type="button"
              onClick={clear}
              style={{
                fontSize: 11,
                color: 'var(--text-muted)',
                background: 'transparent',
                border: 'none',
                cursor: 'pointer',
                padding: '2px 0',
              }}
            >
              Clear filter
            </button>
          )}
          {hasRows && (
            <button
              type="button"
              onClick={handleExport}
              title="Export filtered results as CSV"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                padding: '5px 10px',
                borderRadius: 6,
                border: '1px solid var(--border-default)',
                background: 'var(--bg-body)',
                color: 'var(--text-secondary)',
                fontSize: 12,
                cursor: 'pointer',
              }}
            >
              <Download size={14} />
              Export CSV
            </button>
          )}
          {offline && (
            <span
              className="text-[10px] font-semibold px-2 py-1 rounded"
              style={{
                color: hasRows ? 'var(--accent-amber)' : 'var(--accent-rose)',
                background: hasRows ? 'rgba(245, 158, 11, 0.10)' : 'rgba(244, 63, 94, 0.10)',
                border: `1px solid ${hasRows ? 'rgba(245, 158, 11, 0.30)' : 'rgba(244, 63, 94, 0.30)'}`,
              }}
            >
              {offlineBadgeText}
            </span>
          )}
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full border-collapse" style={{ tableLayout: 'fixed', minWidth: 900 }}>
          <thead>
            <tr className="border-b border-border-default">
              <SortableHeader label="Ticket ID" colKey="id" width={90} />
              <th scope="col" aria-sort="none" style={{ ...thBaseStyle, width: '26%' }}>Subject</th>
              <SortableHeader label="Category" colKey="category" width={150} />
              <SortableHeader label="Severity" colKey="severity" width={70} />
              <SortableHeader label="Confidence" colKey="confidence" width={120} />
              <SortableHeader label="Status" colKey="status" width={100} />
              <th scope="col" aria-sort="none" style={{ ...thBaseStyle, width: 110 }}>Assigned To</th>
              <SortableHeader label="Time" colKey="time" width={80} />
            </tr>
          </thead>
          <tbody>
            {paginatedRows.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-sm text-text-muted">
                  {query ? 'No tickets match your query.' : 'No classifications yet. Submit a ticket to begin.'}
                </td>
              </tr>
            ) : (
              paginatedRows.map(row => {
                const severity = CATEGORY_SEVERITY[row.category] ?? 'info';
                const categoryColor = CATEGORY_COLORS[row.category] ?? 'var(--text-muted)';
                const categoryBg = CATEGORY_BG[row.category] ?? 'rgba(148, 163, 184, 0.12)';
                const severityColor = SEVERITY_COLORS[severity];
                return (
                  <tr
                    key={row.id}
                    className="border-b border-white/[0.03] hover:bg-white/[0.03] transition-colors duration-instant"
                    tabIndex={0}
                    style={{ height: 'var(--density-row-h)' }}
                  >
                    <td style={{ ...tdStyle, width: 90 }}>
                      <a href="#" className="font-mono text-xs text-accent-indigo hover:underline">{row.id}</a>
                    </td>
                    <td style={{ ...tdStyle, width: '26%', fontSize: 13, fontWeight: 500 }} title={row.subject}>
                      {truncate(row.subject, 42)}
                    </td>
                    <td style={{ ...tdStyle, width: 150 }}>
                      <span
                        className="inline-flex items-center gap-1.5 rounded text-[12px] font-semibold tracking-[0.2px]"
                        style={{
                          backgroundColor: categoryBg,
                          color: categoryColor,
                          whiteSpace: 'nowrap',
                          overflow: 'visible',
                          padding: '2px 8px',
                        }}
                      >
                        <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: categoryColor }} />
                        {row.category}
                      </span>
                    </td>
                    <td style={{ ...tdStyle, width: 70 }}>
                      <span
                        className="inline-block w-2 h-2 rounded-full"
                        style={{ backgroundColor: severityColor }}
                        title={`Severity: ${SEVERITY_LABEL[severity]}`}
                        aria-label={`Severity: ${SEVERITY_LABEL[severity]}`}
                      />
                    </td>
                    <td style={{ ...tdStyle, width: 120 }}>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[13px] text-text-primary" style={{ minWidth: 32 }}>{(row.confidence * 100).toFixed(0)}%</span>
                        <span className="w-12 h-[2px] bg-white/[0.06] rounded-sm overflow-hidden inline-block">
                          <span
                            className="h-full rounded-sm bg-accent-emerald block"
                            style={{ width: `${row.confidence * 100}%` }}
                          />
                        </span>
                      </div>
                    </td>
                    <td style={{ ...tdStyle, width: 100 }}>
                      <span
                        className="inline-flex items-center px-2.5 py-1 rounded text-[11px] font-semibold"
                        style={{ backgroundColor: STATUS_COLORS[row.status].bg, color: STATUS_COLORS[row.status].text }}
                      >
                        {row.status}
                      </span>
                    </td>
                    <td style={{ ...tdStyle, width: 110, fontFamily: 'var(--font-numeric)', fontVariantNumeric: 'tabular-nums' }} className="text-text-secondary">{row.assignedTo}</td>
                    <td style={{ ...tdStyle, width: 80, fontFamily: 'var(--font-numeric)', fontVariantNumeric: 'tabular-nums', fontSize: 12 }} className="text-text-muted">{formatRelativeTime(row.createdAt)}</td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
      {hasRows && (
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 20px', borderTop: '1px solid var(--border-default)' }}>
        <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>
          Showing {(currentPage - 1) * pageSize + 1}–{Math.min(currentPage * pageSize, totalCount)} of {totalCount}
          {query && ` (filtered from ${tickets.length})`}
        </span>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <button
            disabled={currentPage === 1}
            aria-disabled={currentPage === 1}
            onClick={() => setPage(p => p - 1)}
            style={{
              padding: '4px 10px',
              borderRadius: 6,
              border: '1px solid var(--border-default)',
              background: 'var(--bg-body)',
              color: currentPage === 1 ? 'var(--text-muted)' : 'var(--text-primary)',
              fontSize: 12,
              cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
            }}
          >
            Previous
          </button>
          <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>Page {currentPage}</span>
          <button
            disabled={currentPage >= pageCount}
            aria-disabled={currentPage >= pageCount}
            onClick={() => setPage(p => p + 1)}
            style={{
              padding: '4px 10px',
              borderRadius: 6,
              border: '1px solid var(--border-default)',
              background: 'var(--bg-body)',
              color: currentPage >= pageCount ? 'var(--text-muted)' : 'var(--text-primary)',
              fontSize: 12,
              cursor: currentPage >= pageCount ? 'not-allowed' : 'pointer',
            }}
          >
            Next
          </button>
        </div>
      </div>
      )}
      <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '6px 20px 8px', borderTop: '1px solid var(--border-default)' }}>
        <span style={{ fontSize: 'var(--caption-size)', color: 'var(--caption-color)' }}>
          {formatLastRefreshed(lastSync, status)}
        </span>
      </div>
    </div>
  );
};
