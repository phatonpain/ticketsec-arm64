import React, { useEffect, useMemo, useState } from 'react';
import { ECharts } from './ECharts';
import type { EChartsCoreOption } from '../lib/echarts';
import { useApi, type PerformancePoint } from '../hooks/useApi';
import { chartColors } from '../lib/chartTokens';


function hexToRgba(hex: string, alpha: number): string {
  const clean = hex.replace('#', '');
  const r = parseInt(clean.substring(0, 2), 16);
  const g = parseInt(clean.substring(2, 4), 16);
  const b = parseInt(clean.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function downsampleTicks(labels: string[], maxTicks: number): string[] {
  if (labels.length <= maxTicks) return labels;
  const step = Math.ceil(labels.length / maxTicks);
  return labels.map((label, i) => (i % step === 0 ? label : ''));
}

export const PerformanceLineChart: React.FC = () => {
  const { status, getPerformance, lastSync } = useApi();
  const [data, setData] = useState<PerformancePoint[]>([]);
  const [isCached, setIsCached] = useState(true);
  const [pending, setPending] = useState(true);

  useEffect(() => {
    let mounted = true;
    setPending(true);
    getPerformance().then(res => {
      if (!mounted) return;
      if (res && res.length > 0) {
        setData(res);
        setIsCached(false);
      } else {
        setData([]);
        setIsCached(true);
      }
      setPending(false);
    });
    return () => { mounted = false; };
  }, [getPerformance]);

  useEffect(() => {
    setIsCached(status !== 'live');
  }, [status]);

  const option: EChartsCoreOption = useMemo(() => {
    const labels = data.map(d => d.time);
    const tickLabels = downsampleTicks(labels, 6);

    return {
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        backgroundColor: chartColors.cardBg,
        borderColor: chartColors.baselineFp32,
        borderWidth: 1,
        textStyle: { color: chartColors.textPrimary, fontFamily: 'JetBrains Mono', fontSize: 12 },
        axisPointer: { type: 'cross', label: { backgroundColor: chartColors.cardBg } },
      },
      legend: {
        data: ['Baseline', 'ONNX Runtime', 'INT8 Quantized'],
        top: 0,
        right: 0,
        textStyle: { color: chartColors.textMuted, fontFamily: 'Inter', fontSize: 11 },
        itemWidth: 14,
        itemHeight: 3,
      },
      grid: { left: 12, right: 12, top: 36, bottom: 24, containLabel: true },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: labels,
        axisLine: { lineStyle: { color: chartColors.baselineFp32 } },
        axisTick: { show: false },
        axisLabel: {
          color: chartColors.textMuted,
          fontFamily: 'Inter',
          fontSize: 10,
          interval: 0,
          formatter: (_value: string, index: number) => tickLabels[index] || '',
        },
      },
      yAxis: {
        type: 'value',
        min: 80,
        max: 100,
        axisLine: { show: false },
        axisLabel: { color: chartColors.textMuted, fontFamily: 'JetBrains Mono', fontSize: 10, formatter: '{value}%' },
        splitLine: { lineStyle: { color: chartColors.baselineFp32 } },
      },
      series: [
        {
          name: 'Baseline',
          type: 'line',
          data: data.map(d => d.baseline.toFixed(2)),
          smooth: true,
          showSymbol: false,
          symbol: 'circle',
          symbolSize: 6,
          lineStyle: { color: chartColors.baseline, width: 2, type: 'dashed' },
          itemStyle: { color: chartColors.baseline },
          areaStyle: { color: hexToRgba(chartColors.baseline, 0.08) },
        },
        {
          name: 'ONNX Runtime',
          type: 'line',
          data: data.map(d => d.onnx.toFixed(2)),
          smooth: true,
          showSymbol: false,
          symbol: 'circle',
          symbolSize: 6,
          lineStyle: { color: chartColors.onnx, width: 2 },
          itemStyle: { color: chartColors.onnx },
          areaStyle: { color: hexToRgba(chartColors.onnx, 0.08) },
        },
        {
          name: 'INT8 Quantized',
          type: 'line',
          data: data.map(d => d.int8.toFixed(2)),
          smooth: true,
          showSymbol: false,
          symbol: 'circle',
          symbolSize: 6,
          lineStyle: { color: chartColors.int8, width: 2 },
          itemStyle: { color: chartColors.int8 },
          areaStyle: { color: hexToRgba(chartColors.int8, 0.08) },
        },
      ],
    };
  }, [data]);

  const caption = lastSync && !isCached
    ? `Last refreshed: ${lastSync.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`
    : lastSync
    ? `Snapshot: cached · ${lastSync.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`
    : 'Snapshot: cached';

  return (
    <div id="performance-chart" className="bg-bg-card border border-border-default rounded-md overflow-hidden hover:border-border-hover transition-colors duration-instant flex flex-col">
      <div className="flex items-center justify-between" style={{ height: 'var(--density-widget-head-h)', padding: '0 20px', boxSizing: 'border-box' }}>
        <div>
          <h2 className="text-[15px] font-semibold text-text-primary tracking-[-0.2px]">Classification Performance</h2>
          <p className="text-xs text-text-muted mt-0.5">Accuracy over the last 24 hours</p>
        </div>
        {isCached && (
          <span className="text-[10px] font-semibold text-accent-amber bg-accent-amber/10 px-2 py-1 rounded">
            CACHED
          </span>
        )}
      </div>
      <div className="px-5 pb-3 flex-1" style={{ position: 'relative' }}>
        {(pending || data.length === 0) ? (
          <div
            style={{
              position: 'absolute',
              inset: 0,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--text-muted)',
              fontSize: 13,
              gap: 8,
            }}
          >
            <span style={{ fontWeight: 600, color: 'var(--text-secondary)' }}>Awaiting live performance data</span>
            <span style={{ fontSize: 11 }}>Historical accuracy will appear once the API returns real metrics.</span>
          </div>
        ) : (
          <ECharts option={option} style={{ width: '100%', height: '280px' }} />
        )}
      </div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '6px 20px 8px', borderTop: '1px solid var(--border-default)' }}>
        <span style={{ fontSize: 'var(--caption-size)', color: 'var(--caption-color)' }}>{caption}</span>
      </div>
    </div>
  );
};
