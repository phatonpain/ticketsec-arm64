export function Footer() {
  return (
    <footer className="h-12 border-t border-border-default flex items-center justify-center px-7 text-xs text-text-muted">
      <span>TicketSec Arm64 Guardian | AWS Graviton Deployment | ONNX Runtime</span>
      <span className="mx-2">·</span>
      <a
        href="http://3.23.60.61:8000/docs"
        target="_blank"
        rel="noreferrer"
        className="text-accent-indigo hover:underline font-medium"
      >
        API Docs
      </a>
      <span className="mx-2">·</span>
      <a
        href="https://github.com/phatonpain/ticketsec-arm64"
        target="_blank"
        rel="noreferrer"
        className="text-accent-indigo hover:underline font-medium"
      >
        GitHub
      </a>
    </footer>
  );
}
