import React, { useId, useState } from 'react';
import type { LucideIcon } from 'lucide-react';
import { Sparkline } from './Sparkline';

interface ChangeBadge {
  type: 'change';
  value: string;
  changeType: 'positive' | 'negative' | 'neutral';
}

interface CachedBadge {
  type: 'cached';
}

interface ModelCardBadge {
  type: 'model-card';
}

interface PendingBadge {
  type: 'pending';
}

type BadgeType = ChangeBadge | CachedBadge | ModelCardBadge | PendingBadge;

interface KpiCardProps {
  icon: LucideIcon;
  iconBg: string;
  iconColor: string;
  label: string;
  value: string;
  detail: string;
  badge?: BadgeType;
  tooltip?: { title?: string; trend?: string; threshold?: string; note?: string };
  sparklineData?: number[];
  sparklineColor?: string;
  muted?: boolean;
}

function slug(label: string): string {
  return label.toLowerCase().replace(/[^a-z0-9]+/g, '-');
}

export const KpiCard: React.FC<KpiCardProps> = ({
  icon: Icon,
  iconBg,
  iconColor,
  label,
  value,
  detail,
  badge,
  tooltip,
  sparklineData,
  sparklineColor = '#06B6D4',
  muted = false,
}) => {
  const [showTooltip, setShowTooltip] = useState(false);
  const tooltipId = useId();
  const hasTooltip = Boolean(tooltip);

  const badgeEl = (() => {
    if (!badge) return null;
    if (badge.type === 'cached') {
      return (
        <span
          style={{
            fontSize: 10,
            fontWeight: 600,
            letterSpacing: '0.3px',
            textTransform: 'uppercase',
            padding: '2px 6px',
            borderRadius: 4,
            color: 'var(--accent-amber)',
            background: 'rgba(245, 158, 11, 0.10)',
            border: '1px solid rgba(245, 158, 11, 0.30)',
          }}
        >
          Cached
        </span>
      );
    }
    if (badge.type === 'model-card') {
      return (
        <span
          style={{
            fontSize: 10,
            fontWeight: 600,
            letterSpacing: '0.3px',
            textTransform: 'uppercase',
            padding: '2px 6px',
            borderRadius: 4,
            color: 'var(--text-muted)',
            background: 'rgba(148, 163, 184, 0.10)',
            border: '1px solid rgba(148, 163, 184, 0.25)',
          }}
        >
          Model Card
        </span>
      );
    }
    if (badge.type === 'pending') {
      return (
        <span
          style={{
            fontSize: 10,
            fontWeight: 600,
            letterSpacing: '0.3px',
            textTransform: 'uppercase',
            padding: '2px 6px',
            borderRadius: 4,
            color: 'var(--text-muted)',
            background: 'rgba(148, 163, 184, 0.10)',
            border: '1px solid rgba(148, 163, 184, 0.25)',
          }}
        >
          Pending Validation
        </span>
      );
    }
    const color =
      badge.changeType === 'positive'
        ? 'var(--accent-emerald)'
        : badge.changeType === 'negative'
        ? 'var(--accent-rose)'
        : 'var(--text-muted)';
    const bg =
      badge.changeType === 'positive'
        ? 'rgba(16, 185, 129, 0.10)'
        : badge.changeType === 'negative'
        ? 'rgba(244, 63, 94, 0.10)'
        : 'rgba(148, 163, 184, 0.10)';
    const border =
      badge.changeType === 'positive'
        ? 'rgba(16, 185, 129, 0.30)'
        : badge.changeType === 'negative'
        ? 'rgba(244, 63, 94, 0.30)'
        : 'rgba(148, 163, 184, 0.25)';
    return (
      <span
        style={{
          fontSize: 10,
          fontWeight: 600,
          letterSpacing: '0.3px',
          padding: '2px 6px',
          borderRadius: 4,
          color,
          background: bg,
          border: `1px solid ${border}`,
        }}
      >
        {badge.value}
      </span>
    );
  })();

  return (
    <div
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border-default)',
        borderRadius: 8,
        padding: 'var(--density-card-pad)',
        height: 'var(--density-kpi-h)',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        position: 'relative',
        transition: 'border-color 150ms ease',
      }}
      onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-hover)'; setShowTooltip(true); }}
      onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-default)'; setShowTooltip(false); }}
      aria-describedby={hasTooltip ? `${tooltipId}-${slug(label)}` : undefined}
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <span
          style={{
            fontSize: 10,
            fontWeight: 600,
            letterSpacing: '0.6px',
            textTransform: 'uppercase',
            color: 'var(--text-muted)',
          }}
        >
          {label}
        </span>
        <div
          style={{
            width: 28,
            height: 28,
            borderRadius: 6,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: iconBg,
            color: iconColor,
            flexShrink: 0,
          }}
        >
          <Icon size={14} />
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 4 }}>
        <span
          style={{
            fontSize: 28,
            fontWeight: 600,
            fontFamily: 'var(--font-numeric)',
            fontVariantNumeric: 'tabular-nums',
            color: muted ? 'var(--text-muted)' : 'var(--text-primary)',
            letterSpacing: '-0.5px',
            lineHeight: 1,
          }}
        >
          {value}
        </span>
        {badgeEl}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 'auto' }}>
        <span
          style={{
            fontSize: 11,
            color: 'var(--text-muted)',
            lineHeight: 1.4,
          }}
        >
          {detail}
        </span>
        {sparklineData && sparklineData.length > 0 && (
          <div style={{ width: 96, flexShrink: 0 }}>
            <Sparkline data={sparklineData} color={sparklineColor} height={32} strokeWidth={1.5} />
          </div>
        )}
      </div>

      {hasTooltip && showTooltip && (
        <div
          id={`${tooltipId}-${slug(label)}`}
          role="tooltip"
          style={{
            position: 'absolute',
            bottom: 'calc(100% + 8px)',
            left: 0,
            right: 0,
            zIndex: 50,
            background: 'var(--bg-elevated)',
            border: '1px solid var(--border-default)',
            borderRadius: 8,
            padding: 10,
            boxShadow: '0 8px 24px rgba(0,0,0,0.35)',
            fontSize: 11,
            color: 'var(--text-secondary)',
            pointerEvents: 'none',
          }}
        >
          {tooltip?.title && <div style={{ fontWeight: 600, color: 'var(--text-primary)', marginBottom: 4 }}>{tooltip.title}</div>}
          {tooltip?.note && <div style={{ marginBottom: 2 }}>{tooltip.note}</div>}
          {tooltip?.trend && <div style={{ marginBottom: 2 }}>{tooltip.trend}</div>}
          {tooltip?.threshold && <div>{tooltip.threshold}</div>}
        </div>
      )}
    </div>
  );
};
