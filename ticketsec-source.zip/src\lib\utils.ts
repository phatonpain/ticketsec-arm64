import { clsx, type ClassValue } from 'clsx';

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

/**
 * Categorical palette mapped to CSS tokens --cat-1..6.
 * Same category = same color in table badges, bar chart, and donut.
 */
export const CATEGORY_COLORS: Record<string, string> = {
  Phishing: 'var(--cat-1)',
  Malware: 'var(--cat-2)',
  'Data Breach': 'var(--cat-3)',
  'Unauthorized Access': 'var(--cat-4)',
  DDoS: 'var(--cat-5)',
  'False Positive': 'var(--cat-6)',
};

export const CATEGORY_BG: Record<string, string> = {
  Phishing: 'rgba(129, 140, 248, 0.12)',
  Malware: 'rgba(34, 211, 238, 0.12)',
  'Data Breach': 'rgba(251, 191, 36, 0.12)',
  'Unauthorized Access': 'rgba(248, 113, 113, 0.12)',
  DDoS: 'rgba(167, 139, 250, 0.12)',
  'False Positive': 'rgba(148, 163, 184, 0.12)',
};

/**
 * Category → severity mapping for the dense classification table.
 */
export const CATEGORY_SEVERITY: Record<string, 'critical' | 'high' | 'medium' | 'info'> = {
  Phishing: 'critical',
  Malware: 'critical',
  'Data Breach': 'critical',
  'Unauthorized Access': 'high',
  DDoS: 'medium',
  'False Positive': 'info',
};

export const SEVERITY_LABEL: Record<string, string> = {
  critical: 'Critical',
  high: 'High',
  medium: 'Medium',
  info: 'Info',
};

export const SEVERITY_COLORS: Record<string, string> = {
  critical: 'var(--sev-critical)',
  high: 'var(--sev-high)',
  medium: 'var(--sev-medium)',
  info: 'var(--sev-info)',
};

export const STATUS_COLORS: Record<string, { bg: string; text: string }> = {
  Resolved: { bg: 'rgba(16, 185, 129, 0.12)', text: '#5EEA9A' },
  Escalated: { bg: 'rgba(244, 63, 94, 0.12)', text: '#F43F5E' },
  Pending: { bg: 'rgba(245, 158, 11, 0.12)', text: '#F59E0B' },
};

export function formatNumber(n: number): string {
  return n.toLocaleString('en-US');
}

export function truncate(str: string, max: number): string {
  if (str.length <= max) return str;
  return str.slice(0, max - 1) + '…';
}

export function generateTicketId(): string {
  return `TKT-${Math.floor(1000 + Math.random() * 9000)}`;
}

import type { PerformancePoint } from '../hooks/useApi';

export function extractLatencySeries(data: PerformancePoint[]): number[] {
  return data.map(p => p.latency_ms ?? 0).filter(v => v > 0);
}

export function extractThroughputSeries(data: PerformancePoint[]): number[] {
  return data.map(p => p.throughput ?? 0).filter(v => v > 0);
}
