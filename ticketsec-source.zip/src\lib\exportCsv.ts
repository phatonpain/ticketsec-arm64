import type { Ticket } from '../hooks/useTickets';

function escapeCsvCell(value: string | number): string {
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function exportTicketsToCsv(tickets: Ticket[], filename = 'ticketsec-classifications.csv'): void {
  if (tickets.length === 0) return;

  const headers = ['ID', 'Subject', 'Category', 'Confidence', 'Status', 'Assigned To', 'Created At'];
  const rows = tickets.map(t => [
    t.id,
    t.subject,
    t.category,
    (t.confidence * 100).toFixed(1),
    t.status,
    t.assignedTo,
    t.createdAt.toISOString(),
  ]);

  const csv = [headers.map(escapeCsvCell).join(','), ...rows.map(row => row.map(escapeCsvCell).join(','))].join('\n');

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
