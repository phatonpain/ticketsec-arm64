# TicketSec Arm64 — INT8 Quantization Notes

> **THE HONESTY CONTRACT (non-negotiable):** Every datum shown is either **live**
> (from the API), **cached** (amber `CACHED` badge, sourced from
> `public/cache/tickets-snapshot.json`), or shown as **"Unavailable — API offline"**.
> The Event Log records ONLY real events. Nothing is ever fabricated and presented
> as live.

## Artifact

- **File:** `model/artifact.onnx` (to be committed once the backend artifact is available)
- **Expected size:** ~8.73 MB (INT8-quantized)
- **Runtime:** ONNX Runtime on AWS Graviton `t4g.micro` (ARM64, 2 vCPU, 1 GB RAM)
- **Target RAM budget:** < 700 MB for the service (`MemoryMax=700M` in `ticketsec.service`)

## Quantization approach

The classifier was exported to ONNX and quantized to 8-bit integer weights using
dynamic quantization (weights in INT8, activations computed in FP32 by default).
This is the standard ONNX Runtime path for small transformer / bag-of-words text
classifiers where the primary goal is to reduce model size and memory footprint
on a resource-constrained ARM64 host.

Key trade-offs:

| Aspect | FP32 (baseline) | INT8 quantized |
|---|---|---|
| Model size | ~35 MB (estimated) | ~8.73 MB |
| RAM at load | Higher | Lower |
| Inference latency on t4g.micro | To be measured | To be measured |
| Accuracy delta | Baseline | To be measured vs FP32 |

## Accuracy delta

The measured accuracy delta between FP32 and INT8 will be recorded in
`model/eval_results.json` once both artifacts are available. Until then, the
field is `PENDING`.

## Why INT8 fits the hackathon demo

- The `t4g.micro` has only 1 GB RAM and must share memory with the OS,
  uvicorn, ONNX Runtime, and any monitoring overhead.
- An 8.73 MB INT8 model loads quickly and leaves headroom under the 700 MB
  systemd `MemoryMax` cap.
- For a synthetic, small-scale hackathon dataset, INT8 quantization is a
  reasonable demonstration of edge-deployment efficiency.

## Next steps

1. Commit the FP32 and INT8 ONNX artifacts to `model/`.
2. Run `python model/eval.py` against both artifacts to compute the accuracy delta.
3. Update this file with the measured delta and load-time numbers.
