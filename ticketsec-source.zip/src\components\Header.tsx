import React, { useState, useRef, useEffect } from 'react';
import { Bell, Settings, RefreshCw, ChevronDown } from 'lucide-react';
import { useApi } from '../hooks/useApi';
import { useEventLog } from '../hooks/useEventLog';
import { openSettingsDrawer } from '../hooks/useSettingsDrawer';
import { formatRelativeTime } from '../lib/formatRelativeTime';

const TIME_OPTIONS = ['Last 1 hour', 'Last 6 hours', 'Last 24 hours', 'Last 7 days'];

export const Header: React.FC = () => {
  const { status, checkHealth, checking, diagnostics, lastSync } = useApi();
  const { logs, unreadCount, markAllRead } = useEventLog(50);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [selectedTime, setSelectedTime] = useState('Last 24 hours');
  const [notifOpen, setNotifOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [statusTooltipOpen, setStatusTooltipOpen] = useState(false);

  const dropdownRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);
  const statusRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setNotifOpen(false);
      }
      if (statusRef.current && !statusRef.current.contains(event.target as Node)) {
        setStatusTooltipOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 0);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (!notifOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setNotifOpen(false);
    };
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [notifOpen]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await checkHealth();
    setIsRefreshing(false);
  };

  const handleToggleNotifications = () => {
    if (!notifOpen && unreadCount > 0) {
      markAllRead();
    }
    setNotifOpen(prev => !prev);
  };

  const statusConfig = checking
    ? { label: 'Checking…', color: 'var(--text-muted)', bg: 'rgba(148,163,184,0.08)', border: 'rgba(148,163,184,0.30)', dot: 'var(--text-muted)', spinning: true }
    : status === 'live'
    ? { label: 'System Online', color: 'var(--accent-emerald)', bg: 'rgba(16,185,129,0.08)', border: 'rgba(16,185,129,0.30)', dot: 'var(--accent-emerald)', spinning: false }
    : status === 'cached'
    ? { label: 'System Cached', color: 'var(--accent-amber)', bg: 'rgba(245,158,11,0.08)', border: 'rgba(245,158,11,0.30)', dot: 'var(--accent-amber)', spinning: false }
    : { label: 'System Offline', color: 'var(--accent-rose)', bg: 'rgba(244,63,94,0.08)', border: 'rgba(244,63,94,0.30)', dot: 'var(--accent-rose)', spinning: false };

  const iconButtonStyle: React.CSSProperties = {
    width: 34,
    height: 34,
    borderRadius: 8,
    border: '1px solid var(--border-default)',
    background: 'transparent',
    color: 'var(--text-secondary)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    transition: 'all 150ms ease',
    position: 'relative',
  };

  const recentNotifications = logs.slice(0, 8);

  return (
    <header
      style={{
        height: 56,
        padding: '0 28px',
        borderBottom: `1px solid ${scrolled ? 'var(--border-hover)' : 'var(--border-default)'}`,
        background: 'var(--bg-body)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        position: 'sticky',
        top: 0,
        zIndex: 90,
        isolation: 'isolate',
        boxShadow: scrolled ? '0 4px 12px rgba(0,0,0,0.25)' : 'none',
      }}
    >
      {/* Breadcrumb */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--text-muted)' }}>
        <span style={{ color: 'var(--text-secondary)' }}>Dashboard</span>
        <span style={{ fontSize: 11 }}>›</span>
        <span style={{ color: 'var(--text-primary)', fontWeight: 600 }}>Security Operations</span>
      </div>

      {/* Right side */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        {/* Status Pill */}
        <div
          ref={statusRef}
          style={{ position: 'relative' }}
          onMouseEnter={() => setStatusTooltipOpen(true)}
          onMouseLeave={() => setStatusTooltipOpen(false)}
          onFocus={() => setStatusTooltipOpen(true)}
          onBlur={() => setStatusTooltipOpen(false)}
        >
          <div
            tabIndex={0}
            role="button"
            aria-describedby="status-tooltip"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              padding: '5px 12px',
              borderRadius: 20,
              border: `1px solid ${statusConfig.border}`,
              background: statusConfig.bg,
              fontSize: 12,
              fontWeight: 600,
              whiteSpace: 'nowrap',
              color: statusConfig.color,
              cursor: 'help',
              outline: 'none',
            }}
          >
            <span
              style={{
                width: 6,
                height: 6,
                borderRadius: '50%',
                background: statusConfig.dot,
                display: 'inline-block',
                marginRight: 6,
                flexShrink: 0,
                animation: statusConfig.spinning ? 'pulse 1.2s ease-in-out infinite' : 'none',
              }}
            />
            {statusConfig.label}
          </div>
          {statusTooltipOpen && (
            <div
              id="status-tooltip"
              role="tooltip"
              style={{
                position: 'absolute',
                top: 'calc(100% + 8px)',
                right: 0,
                width: 280,
                background: 'var(--bg-elevated)',
                border: '1px solid var(--border-default)',
                borderRadius: 8,
                padding: 12,
                zIndex: 100,
                boxShadow: '0 8px 24px rgba(0,0,0,0.30)',
              }}
            >
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 8 }}>
                Connection Diagnostics
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>
                  Status: <span style={{ color: statusConfig.color, fontWeight: 500 }}>{statusConfig.label}</span>
                </div>
                {lastSync && (
                  <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>
                    Last sync: {formatRelativeTime(lastSync)}
                  </div>
                )}
                {diagnostics.lastProbe && (
                  <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>
                    Probed: {formatRelativeTime(diagnostics.lastProbe)}
                  </div>
                )}
                {diagnostics.lastError && (
                  <div style={{ fontSize: 11, color: 'var(--accent-rose)' }}>
                    Error: {diagnostics.lastError}
                  </div>
                )}
                <div style={{ marginTop: 4, borderTop: '1px solid var(--border-default)', paddingTop: 8 }}>
                  <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 6 }}>
                    Endpoints
                  </div>
                  {diagnostics.endpoints.length === 0 ? (
                    <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>No probes yet.</div>
                  ) : (
                    diagnostics.endpoints.map(endpoint => (
                      <div key={endpoint.url} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 11, marginBottom: 4 }}>
                        <span style={{ color: 'var(--text-secondary)', maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis' }} title={endpoint.url}>
                          {endpoint.url}
                        </span>
                        <span style={{ color: endpoint.ok ? 'var(--accent-emerald)' : 'var(--accent-rose)', fontWeight: 500, flexShrink: 0 }}>
                          {endpoint.ok ? `${endpoint.latencyMs}ms` : (endpoint.error ?? 'Fail')}
                        </span>
                      </div>
                    ))
                  )}
                </div>
                <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 4 }}>
                  Auto-recovery probes every 30s with backoff.
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Refresh */}
        <button
          onClick={handleRefresh}
          aria-label="Refresh data"
          style={iconButtonStyle}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)';
            (e.currentTarget as HTMLElement).style.color = 'var(--text-primary)';
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLElement).style.background = 'transparent';
            (e.currentTarget as HTMLElement).style.color = 'var(--text-secondary)';
          }}
        >
          <RefreshCw
            size={16}
            style={{
              animation: isRefreshing ? 'spin 1s linear infinite' : 'none',
            }}
          />
        </button>

        {/* Time Range Dropdown */}
        <div ref={dropdownRef} style={{ position: 'relative' }}>
          <button
            onClick={() => setDropdownOpen(prev => !prev)}
            aria-haspopup="listbox"
            aria-expanded={dropdownOpen}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              padding: '6px 12px',
              borderRadius: 6,
              border: '1px solid var(--border-default)',
              background: 'var(--bg-card)',
              color: 'var(--text-secondary)',
              fontSize: 13,
              cursor: 'pointer',
            }}
          >
            {selectedTime} <ChevronDown size={14} />
          </button>
          {dropdownOpen && (
            <div
              role="listbox"
              style={{
                position: 'absolute',
                top: 'calc(100% + 6px)',
                right: 0,
                minWidth: 160,
                background: 'var(--bg-elevated)',
                border: '1px solid var(--border-default)',
                borderRadius: 8,
                padding: '6px 0',
                zIndex: 100,
                boxShadow: '0 8px 24px rgba(0,0,0,0.30)',
              }}
            >
              {TIME_OPTIONS.map(option => (
                <div
                  key={option}
                  role="option"
                  aria-selected={option === selectedTime}
                  tabIndex={0}
                  onClick={() => { setSelectedTime(option); setDropdownOpen(false); }}
                  onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { setSelectedTime(option); setDropdownOpen(false); } }}
                  style={{
                    padding: '8px 14px',
                    fontSize: 13,
                    color: option === selectedTime ? 'var(--text-primary)' : 'var(--text-secondary)',
                    background: option === selectedTime ? 'rgba(99,102,241,0.10)' : 'transparent',
                    cursor: 'pointer',
                  }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)'; }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = option === selectedTime ? 'rgba(99,102,241,0.10)' : 'transparent'; }}
                >
                  {option}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Notifications */}
        <div ref={notifRef} style={{ position: 'relative' }}>
          <button
            onClick={handleToggleNotifications}
            aria-label={`Notifications${unreadCount > 0 ? `, ${unreadCount} unread` : ''}`}
            style={iconButtonStyle}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)';
              (e.currentTarget as HTMLElement).style.color = 'var(--text-primary)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.background = 'transparent';
              (e.currentTarget as HTMLElement).style.color = 'var(--text-secondary)';
            }}
          >
            <Bell size={16} />
            {unreadCount > 0 && (
              <span
                style={{
                  position: 'absolute',
                  top: 6,
                  right: 6,
                  minWidth: 14,
                  height: 14,
                  borderRadius: 7,
                  background: 'var(--accent-rose)',
                  color: '#fff',
                  fontSize: 9,
                  fontWeight: 700,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  padding: '0 3px',
                }}
              >
                {unreadCount}
              </span>
            )}
          </button>
          {notifOpen && (
            <div
              style={{
                position: 'absolute',
                top: 'calc(100% + 6px)',
                right: 0,
                width: 340,
                maxHeight: 360,
                overflowY: 'auto',
                background: 'var(--bg-elevated)',
                border: '1px solid var(--border-default)',
                borderRadius: 8,
                padding: '12px 0',
                zIndex: 100,
                boxShadow: '0 8px 24px rgba(0,0,0,0.30)',
              }}
            >
              <div style={{ padding: '0 14px 8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>Notifications</span>
                <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{recentNotifications.length} events</span>
              </div>
              {recentNotifications.length === 0 ? (
                <div style={{ padding: '16px 14px', textAlign: 'center', fontSize: 12, color: 'var(--text-muted)' }}>
                  No notifications yet.
                </div>
              ) : (
                recentNotifications.map(entry => {
                  const levelColor = entry.level === 'INFO'
                    ? 'var(--accent-emerald)'
                    : entry.level === 'WARN'
                    ? 'var(--accent-amber)'
                    : entry.level === 'ERROR'
                    ? 'var(--accent-rose)'
                    : 'var(--text-muted)';
                  return (
                    <div
                      key={entry.id}
                      style={{
                        padding: '10px 14px',
                        borderBottom: '1px solid rgba(255,255,255,0.03)',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 4,
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ width: 6, height: 6, borderRadius: '50%', background: levelColor, flexShrink: 0 }} />
                        <span style={{ fontSize: 12, color: 'var(--text-primary)', fontWeight: 500 }}>{entry.message}</span>
                      </div>
                      <span style={{ fontSize: 11, color: 'var(--text-muted)', paddingLeft: 14 }}>
                        {formatRelativeTime(entry.timestamp)} · {entry.level}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>

        {/* Settings */}
        <button
          onClick={openSettingsDrawer}
          aria-label="Settings"
          style={iconButtonStyle}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.04)';
            (e.currentTarget as HTMLElement).style.color = 'var(--text-primary)';
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLElement).style.background = 'transparent';
            (e.currentTarget as HTMLElement).style.color = 'var(--text-secondary)';
          }}
        >
          <Settings size={16} />
        </button>
      </div>
    </header>
  );
};
