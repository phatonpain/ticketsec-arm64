/**
 * Static hex colors for ECharts canvas rendering.
 * These values mirror the semantic tokens in src/styles/tokens.css.
 * Keep in sync when the design tokens change.
 */
export const chartColors = {
  // Performance line series
  baseline: '#64748B',
  onnx: '#6366F1',
  int8: '#06B6D4',

  // Model footprint donut
  modelInt8: '#6366F1',
  baselineFp32: '#64748B',
  tokenizerConfig: '#8B5CF6',

  // Categorical palette (charts, table badges, donut)
  // Mirrors --color-cat-1..6 / --cat-1..6
  cat1: '#818cf8',
  cat2: '#22d3ee',
  cat3: '#fbbf24',
  cat4: '#f87171',
  cat5: '#a78bfa',
  cat6: '#94a3b8',

  // Severity palette (functional, Splunk-class)
  // Mirrors --color-sev-* / --sev-*
  sevCritical: '#f87171',
  sevHigh: '#f97316',
  sevMedium: '#eab308',
  sevLow: '#22c55e',
  sevInfo: '#60a5fa',

  // Text / utility
  textPrimary: '#F8FAFC',
  textMuted: '#8292A8',
  cardBg: '#1E293B',
} as const;

/**
 * Ordered array for charts that need a consistent categorical sequence.
 */
export const categoryChartColors = [
  chartColors.cat1,
  chartColors.cat2,
  chartColors.cat3,
  chartColors.cat4,
  chartColors.cat5,
  chartColors.cat6,
] as const;

/**
 * Severity palette as an ordered array (critical → info).
 */
export const severityChartColors = [
  chartColors.sevCritical,
  chartColors.sevHigh,
  chartColors.sevMedium,
  chartColors.sevLow,
  chartColors.sevInfo,
] as const;
