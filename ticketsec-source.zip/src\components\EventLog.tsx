import React, { useEffect, useRef, useState } from 'react';
import { useEventLog, type LogLevel } from '../hooks/useEventLog';
import { useApi } from '../hooks/useApi';

const FILTERS: { key: LogLevel | 'ALL'; label: string }[] = [
  { key: 'ALL', label: 'All' },
  { key: 'INFO', label: 'Info' },
  { key: 'DEBUG', label: 'Debug' },
  { key: 'ERROR', label: 'Error' },
];

const LEVEL_STYLES: Record<LogLevel, { color: string; border: string; bg: string }> = {
  INFO: { color: 'var(--accent-emerald)', border: 'rgba(16, 185, 129, 0.60)', bg: 'rgba(16, 185, 129, 0.08)' },
  WARN: { color: 'var(--accent-amber)', border: 'rgba(245, 158, 11, 0.60)', bg: 'rgba(245, 158, 11, 0.08)' },
  ERROR: { color: 'var(--accent-rose)', border: 'rgba(244, 63, 94, 0.60)', bg: 'rgba(244, 63, 94, 0.08)' },
  DEBUG: { color: 'var(--text-muted)', border: 'rgba(130, 146, 168, 0.60)', bg: 'rgba(130, 146, 168, 0.08)' },
};

export const EventLog: React.FC = () => {
  const { logs } = useEventLog(100);
  const { status, lastSync } = useApi();
  const [filter, setFilter] = useState<LogLevel | 'ALL'>('ALL');
  const scrollRef = useRef<HTMLDivElement>(null);

  const filteredLogs = filter === 'ALL' ? logs : logs.filter(entry => entry.level === filter);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [logs, filter]);

  const caption = lastSync && status !== 'live'
    ? `Snapshot: cached · ${lastSync.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`
    : lastSync
    ? `Last refreshed: ${lastSync.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`
    : 'Snapshot: cached';

  return (
    <div
      id="event-log"
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border-default)',
        borderRadius: 8,
        overflow: 'hidden',
        transition: 'border-color 150ms ease',
        display: 'flex',
        flexDirection: 'column',
      }}
      onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-hover)'; }}
      onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-default)'; }}
    >
      <div style={{ height: 'var(--density-widget-head-h)', padding: '0 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', boxSizing: 'border-box' }}>
        <div>
          <h2 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-primary)', letterSpacing: '-0.2px' }}>Event Log</h2>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 1 }}>System activity stream</p>
        </div>
      </div>

      <div style={{ padding: '0 20px 12px' }}>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {FILTERS.map(f => {
            const active = filter === f.key;
            return (
              <button
                key={f.key}
                type="button"
                onClick={() => setFilter(f.key)}
                style={{
                  fontSize: 11,
                  fontWeight: 600,
                  padding: '3px 10px',
                  borderRadius: 4,
                  border: '1px solid var(--border-default)',
                  background: active ? 'rgba(99, 102, 241, 0.12)' : 'transparent',
                  color: active ? 'var(--text-primary)' : 'var(--text-muted)',
                  cursor: 'pointer',
                  transition: 'all 150ms ease',
                }}
              >
                {f.label}
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ padding: '0 20px 16px', flex: 1, minHeight: 0 }}>
        <div
          ref={scrollRef}
          style={{
            background: 'var(--bg-body)',
            border: '1px solid var(--border-default)',
            borderRadius: 8,
            padding: filteredLogs.length > 0 ? '8px 0' : 0,
            maxHeight: 240,
            minHeight: filteredLogs.length > 0 ? undefined : 100,
            overflowY: 'auto',
            overflowX: 'auto',
            fontFamily: 'var(--font-numeric)',
            fontVariantNumeric: 'tabular-nums',
            fontSize: 11,
            lineHeight: 1.5,
            color: 'var(--text-secondary)',
          }}
        >
          {filteredLogs.length === 0 ? (
            <div
              style={{
                height: 100,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: '0 16px',
                textAlign: 'center',
              }}
            >
              <span style={{ color: 'var(--text-muted)' }}>
                {logs.length === 0 ? 'No events yet — system activity will appear here.' : 'No events match the selected filter.'}
              </span>
            </div>
          ) : (
            filteredLogs.map(entry => {
              const style = LEVEL_STYLES[entry.level];
              return (
                <div
                  key={entry.id}
                  style={{
                    padding: '3px 14px',
                    borderBottom: '1px solid rgba(255,255,255,0.03)',
                    whiteSpace: 'nowrap',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                  }}
                  title={entry.message}
                >
                  <span style={{ color: 'var(--text-muted)', opacity: 0.7, minWidth: 64 }}>
                    {entry.timestamp.toTimeString().slice(0, 8)}
                  </span>
                  <span
                    style={{
                      fontSize: 9,
                      fontWeight: 700,
                      letterSpacing: '0.4px',
                      textTransform: 'uppercase',
                      padding: '1px 5px',
                      borderRadius: 3,
                      color: style.color,
                      background: style.bg,
                      borderLeft: `2px solid ${style.border}`,
                      minWidth: 38,
                      textAlign: 'center',
                    }}
                  >
                    {entry.level}
                  </span>
                  <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{entry.message}</span>
                </div>
              );
            })
          )}
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '6px 20px 8px', borderTop: '1px solid var(--border-default)' }}>
        <span style={{ fontSize: 'var(--caption-size)', color: 'var(--caption-color)' }}>{caption}</span>
      </div>
    </div>
  );
};
