import React from 'react';

interface HelpModalProps {
  open: boolean;
  onClose: () => void;
}

interface Shortcut {
  keys: string[];
  description: string;
}

const SHORTCUTS: Shortcut[] = [
  { keys: ['/'], description: 'Focus the ticket query search box' },
  { keys: ['r'], description: 'Refresh API health and data' },
  { keys: ['?'], description: 'Open this keyboard shortcuts help' },
  { keys: ['Esc'], description: 'Close modals, drawers, and dropdowns' },
];

export const HelpModal: React.FC<HelpModalProps> = ({ open, onClose }) => {
  if (!open) return null;

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 300,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'rgba(0,0,0,0.60)',
        padding: 20,
      }}
      onClick={onClose}
      role="presentation"
    >
      <div
        style={{
          width: '100%',
          maxWidth: 420,
          background: 'var(--bg-sidebar)',
          border: '1px solid var(--border-default)',
          borderRadius: 12,
          padding: 24,
          boxShadow: '0 16px 48px rgba(0,0,0,0.40)',
        }}
        onClick={e => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-labelledby="help-title"
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <h2 id="help-title" style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-primary)' }}>
            Keyboard Shortcuts
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close help"
            style={{
              background: 'transparent',
              border: 'none',
              color: 'var(--text-secondary)',
              cursor: 'pointer',
              fontSize: 12,
              padding: 4,
            }}
          >
            Esc
          </button>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {SHORTCUTS.map(shortcut => (
            <div key={shortcut.description} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16 }}>
              <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{shortcut.description}</span>
              <span style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
                {shortcut.keys.map(key => (
                  <kbd
                    key={key}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      minWidth: 28,
                      height: 24,
                      padding: '0 8px',
                      borderRadius: 4,
                      border: '1px solid var(--border-default)',
                      background: 'var(--bg-card)',
                      color: 'var(--text-primary)',
                      fontSize: 12,
                      fontFamily: 'JetBrains Mono, monospace',
                    }}
                  >
                    {key}
                  </kbd>
                ))}
              </span>
            </div>
          ))}
        </div>

        <p style={{ marginTop: 20, fontSize: 12, color: 'var(--text-muted)', lineHeight: 1.5 }}>
          Shortcuts are active while no text input is focused. Press <kbd style={{ fontFamily: 'inherit' }}>Esc</kbd> to close.
        </p>
      </div>
    </div>
  );
};
