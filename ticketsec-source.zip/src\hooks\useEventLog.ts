import { useCallback, useRef, useEffect, useSyncExternalStore } from 'react';

export type LogLevel = 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';

export interface LogEntry {
  id: string;
  timestamp: Date;
  level: LogLevel;
  message: string;
}

const LEVEL_COLORS: Record<LogLevel, string> = {
  INFO: 'text-accent-emerald',
  WARN: 'text-accent-amber',
  ERROR: 'text-accent-rose',
  DEBUG: 'text-text-muted',
};

const LAST_READ_KEY = 'ticketsec-notifications-last-read';

function formatTime(date: Date): string {
  return date.toTimeString().slice(0, 8);
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

function readLastRead(): number {
  try {
    const raw = localStorage.getItem(LAST_READ_KEY);
    if (raw) {
      const parsed = parseInt(raw, 10);
      if (!Number.isNaN(parsed)) return parsed;
    }
  } catch {
    // Storage may be unavailable.
  }
  return 0;
}

function writeLastRead(timestamp: number): void {
  try {
    localStorage.setItem(LAST_READ_KEY, String(timestamp));
  } catch {
    // Ignore storage errors.
  }
}

interface EventLogStore {
  logs: LogEntry[];
  lastRead: number;
  listeners: Set<() => void>;
  initialized: boolean;
}

const store: EventLogStore = {
  logs: [],
  lastRead: readLastRead(),
  listeners: new Set(),
  initialized: false,
};

function emit() {
  store.listeners.forEach(listener => listener());
}

const INITIAL_LOGS: { level: LogLevel; message: string }[] = [
  { level: 'DEBUG', message: 'Health probe started' },
  { level: 'INFO', message: 'Dashboard initialized' },
];

function initializeLogs(maxEntries: number) {
  if (store.initialized) return;
  store.initialized = true;
  INITIAL_LOGS.forEach(l => addLogEntry(l.level, l.message, maxEntries));
}

function addLogEntry(level: LogLevel, message: string, maxEntries: number) {
  const entry: LogEntry = {
    id: generateId(),
    timestamp: new Date(),
    level,
    message,
  };
  store.logs = [entry, ...store.logs].slice(0, maxEntries);
  emit();
}

function subscribe(listener: () => void) {
  store.listeners.add(listener);
  return () => store.listeners.delete(listener);
}

function getSnapshot(): EventLogStore {
  return store;
}

function markAllRead() {
  const now = Date.now();
  store.lastRead = now;
  writeLastRead(now);
  emit();
}

function getUnreadCount(): number {
  return store.logs.filter(entry => entry.timestamp.getTime() > store.lastRead).length;
}

export function useEventLog(maxEntries = 100) {
  initializeLogs(maxEntries);

  const state = useSyncExternalStore(subscribe, getSnapshot);
  const bottomRef = useRef<HTMLDivElement>(null);

  const addLog = useCallback((level: LogLevel, message: string) => {
    addLogEntry(level, message, maxEntries);
  }, [maxEntries]);

  const addInfo = useCallback((message: string) => addLog('INFO', message), [addLog]);
  const addWarn = useCallback((message: string) => addLog('WARN', message), [addLog]);
  const addError = useCallback((message: string) => addLog('ERROR', message), [addLog]);
  const addDebug = useCallback((message: string) => addLog('DEBUG', message), [addLog]);

  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: 'auto' });
    }
  }, [state.logs]);

  const renderLog = useCallback((entry: LogEntry) => {
    return {
      ...entry,
      formattedTime: formatTime(entry.timestamp),
      levelColor: LEVEL_COLORS[entry.level],
    };
  }, []);

  const unreadCount = getUnreadCount();

  return {
    logs: state.logs,
    unreadCount,
    addLog,
    addInfo,
    addWarn,
    addError,
    addDebug,
    markAllRead,
    bottomRef,
    renderLog,
  };
}
